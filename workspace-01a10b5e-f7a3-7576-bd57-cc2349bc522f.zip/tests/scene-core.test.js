import test from 'node:test';
import assert from 'node:assert/strict';
import {
  applySceneCommands, countObjects, createScene, findNode, formatSceneCode,
  normalizeSceneData, parseSceneCode, sceneToCode
} from '../shared/scene-core.js';

test('parses and validates literal Scene API commands', () => {
  const commands = parseSceneCode(`
    environment({ background: "#101a2a", grid: true });
    createBox({ name: "Red Cube", size: [2, 2, 2], position: [0, 1, 0], material: { color: "#ff0000", roughness: 0.4 } });
  `);
  const scene = applySceneCommands(createScene('Test'), commands);
  assert.equal(scene.environment.background, '#101a2a');
  assert.equal(scene.environment.grid, true);
  assert.equal(countObjects(scene), 1);
  assert.equal(findNode(scene, 'Red Cube').material.color, '#ff0000');
});

test('round-trips nested groups, materials, lights, and transforms', () => {
  const original = applySceneCommands(createScene('Round trip'), parseSceneCode(`
    createMaterial({ name: "Steel", color: "#aabbd0", metalness: 0.9, roughness: 0.2 });
    group({ name: "Assembly", position: [1, 0, 2], children: [
      { type: "box", name: "Housing", size: [2, 1, 2], position: [0, 0.5, 0], material: "Steel" },
      { type: "group", name: "Details", children: [{ type: "sphere", name: "Indicator", radius: 0.2, position: [0, 1, 0] }] }
    ] });
    directionalLight({ name: "Key", position: [4, 8, 5], intensity: 2, castShadow: true });
  `));
  const code = sceneToCode(original);
  const formatted = formatSceneCode(code);
  const roundTripped = applySceneCommands(createScene('Round trip'), parseSceneCode(formatted));
  assert.equal(countObjects(roundTripped), countObjects(original));
  assert.equal(findNode(roundTripped, 'Indicator')?.type, 'sphere');
  assert.equal(findNode(roundTripped, 'Assembly')?.position[0], 1);
  assert.equal(roundTripped.materials[0].metalness, 0.9);
});

test('blocks arbitrary JavaScript and unsafe properties', () => {
  assert.throws(() => parseSceneCode('eval("alert(1)")'), /Unknown command/);
  assert.throws(() => parseSceneCode('createBox({ name: "Cube" }); process.exit(1);'), /Unsupported character/);
  assert.throws(() => parseSceneCode('createBox({ "__proto__": {} });'), /Unsafe property/);
  assert.throws(() => applySceneCommands(createScene(), parseSceneCode('createBox({ size: [1, 2] });')), /exactly 3 numbers/);
  assert.throws(() => parseSceneCode(`createBox({name:"x", extra:${'['.repeat(68)}0${']'.repeat(68)}});`), /nested too deeply/);
  assert.throws(() => parseSceneCode(' '.repeat(100001)), /100 KB safety limit/);
});

test('procedural scatter is deterministic and bounded', () => {
  const source = 'scatter({ count: 12, area: [10, 10], seed: 42, object: { type: "sphere", name: "Pebble", radius: 0.25 } });';
  const a = applySceneCommands(createScene(), parseSceneCode(source));
  const b = applySceneCommands(createScene(), parseSceneCode(source));
  assert.deepEqual(a.objects.map((node) => node.position), b.objects.map((node) => node.position));
  assert.equal(countObjects(a), 12);
  assert.throws(() => applySceneCommands(createScene(), parseSceneCode(source.replace('count: 12', 'count: 201'))), /between 1 and 200/);
});

test('enforces scene object limit', () => {
  const tooMany = `repeat({ count: 200, step: [1,0,0], object: { type: "box", name: "Block" } });\nrepeat({ count: 200, step: [1,0,0], object: { type: "box", name: "Block" } });\nrepeat({ count: 120, step: [1,0,0], object: { type: "box", name: "Block" } });`;
  assert.throws(() => applySceneCommands(createScene(), parseSceneCode(tooMany)), /Object count limit exceeded/);
});

test('normalizes imported scenes and rejects duplicate identifiers', () => {
  const scene = applySceneCommands(createScene('Import'), parseSceneCode('group({name:"Kit",children:[{type:"box",name:"Part",size:[1,1,1]}]});'));
  assert.equal(countObjects(normalizeSceneData(scene)), 2);
  const duplicate = structuredClone(scene);
  duplicate.objects[0].children[0].id = duplicate.objects[0].id;
  assert.throws(() => normalizeSceneData(duplicate), /Duplicate object ID/);
});
