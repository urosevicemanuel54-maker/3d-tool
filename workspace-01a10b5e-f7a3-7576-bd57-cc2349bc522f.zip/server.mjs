import express from 'express';
import { createServer } from 'node:http';
import { randomUUID, timingSafeEqual } from 'node:crypto';
import { existsSync } from 'node:fs';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { WebSocketServer, WebSocket } from 'ws';
import { z } from 'zod';
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/streamableHttp.js';
import {
  addNode, applySceneCommands, cloneValue, countObjects, createId, createNode,
  createScene, duplicateNode, findNode, flattenObjects, normalizeSceneData, parseSceneCode, removeNode,
  updateNode, walkNodes
} from './shared/scene-core.js';

const root = fileURLToPath(new URL('.', import.meta.url));
const app = express();
const httpServer = createServer(app);
const PORT = Number(process.env.PORT || 5173);
const production = process.env.NODE_ENV === 'production';
const sceneStore = new Map();
const websocketClients = new Map();
const protocolSessions = new Map();
const selectionByScene = new Map();

app.disable('x-powered-by');
app.use(express.json({ limit: '5mb', strict: true }));

function validSessionId(value) {
  return typeof value === 'string' && /^[a-zA-Z0-9_-]{12,128}$/.test(value);
}
function getSessionId(req) {
  const id = String(req.query.sessionId || req.headers['x-studio-session'] || '');
  return validSessionId(id) ? id : null;
}
function ensureScene(sessionId) {
  if (!sceneStore.has(sessionId)) sceneStore.set(sessionId, { scene: createScene(), history: [], redo: [], updatedAt: new Date().toISOString() });
  return sceneStore.get(sessionId);
}
function sendToScene(sessionId, payload, excludeClientId = null) {
  const clients = websocketClients.get(sessionId);
  if (!clients) return;
  const message = JSON.stringify(payload);
  for (const client of clients) {
    if (client.readyState === WebSocket.OPEN && client.clientId !== excludeClientId) client.send(message);
  }
}
function recordScene(sessionId, nextScene, { source = 'mcp', clientId = null, recordUndo = true } = {}) {
  const record = ensureScene(sessionId);
  if (recordUndo) {
    record.history.push(cloneValue(record.scene));
    if (record.history.length > 50) record.history.shift();
    record.redo = [];
  }
  record.scene = cloneValue(nextScene);
  record.updatedAt = new Date().toISOString();
  sendToScene(sessionId, { type: 'scene:update', scene: record.scene, source, updatedAt: record.updatedAt }, clientId);
  return record;
}
function mutateScene(sessionId, mutator, options = {}) {
  const record = ensureScene(sessionId);
  const next = cloneValue(record.scene);
  const result = mutator(next);
  const validated = normalizeSceneData(next);
  if (countObjects(validated) > 500) throw new Error('Object count limit exceeded (500).');
  recordScene(sessionId, validated, options);
  return { scene: validated, result };
}
function safeAuth(req, res) {
  const configured = process.env.MCP_API_TOKEN;
  if (!configured) return true;
  const supplied = String(req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  const a = Buffer.from(supplied);
  const b = Buffer.from(configured);
  const equal = a.length === b.length && timingSafeEqual(a, b);
  if (equal) return true;
  res.status(401).json({ error: 'Authentication required. Configure the MCP bearer token.' });
  return false;
}

app.get('/api/health', (_req, res) => res.json({ ok: true, name: 'AI 3D Studio', mcp: '/mcp', transport: 'streamable-http' }));
app.get('/api/scenes/:sessionId', (req, res) => {
  const { sessionId } = req.params;
  if (!validSessionId(sessionId)) return res.status(400).json({ error: 'Invalid scene session ID.' });
  const record = sceneStore.get(sessionId);
  if (!record) return res.status(404).json({ error: 'Scene session not found.' });
  res.json({ scene: record.scene, updatedAt: record.updatedAt });
});
app.put('/api/scenes/:sessionId', (req, res) => {
  const { sessionId } = req.params;
  if (!validSessionId(sessionId)) return res.status(400).json({ error: 'Invalid scene session ID.' });
  const scene = req.body?.scene;
  if (!scene) return res.status(400).json({ error: 'Invalid Scene JSON.' });
  let normalized;
  try { normalized = normalizeSceneData(scene); }
  catch (error) { return res.status(400).json({ error: error.message || 'Invalid Scene JSON.' }); }
  try {
    const clientId = String(req.body?.clientId || '');
    const record = recordScene(sessionId, normalized, { source: req.body?.source || 'browser', clientId, recordUndo: req.body?.recordUndo !== false });
    res.json({ ok: true, updatedAt: record.updatedAt });
  } catch (error) {
    res.status(400).json({ error: error.message || 'Could not save scene.' });
  }
});
app.post('/api/scenes/:sessionId/selection', (req, res) => {
  const { sessionId } = req.params;
  if (!validSessionId(sessionId)) return res.status(400).json({ error: 'Invalid scene session ID.' });
  selectionByScene.set(sessionId, req.body?.objectId || null);
  res.json({ ok: true });
});
app.get('/api/scenes/:sessionId/export', (req, res) => {
  const { sessionId } = req.params;
  if (!validSessionId(sessionId)) return res.status(400).json({ error: 'Invalid scene session ID.' });
  const record = sceneStore.get(sessionId);
  if (!record) return res.status(404).json({ error: 'Scene not found.' });
  res.json(record.scene);
});

const wss = new WebSocketServer({ noServer: true, maxPayload: 256 * 1024 });
httpServer.on('upgrade', (request, socket, head) => {
  let url;
  try { url = new URL(request.url, `http://${request.headers.host || 'localhost'}`); } catch { socket.destroy(); return; }
  if (url.pathname !== '/sync') return;
  const sessionId = url.searchParams.get('sessionId');
  const clientId = url.searchParams.get('clientId');
  if (!validSessionId(sessionId) || !/^[a-zA-Z0-9_-]{6,100}$/.test(clientId || '')) { socket.destroy(); return; }
  const origin = request.headers.origin;
  if (origin) {
    try {
      const originUrl = new URL(origin);
      const host = request.headers.host;
      if (originUrl.host !== host && process.env.ALLOWED_ORIGIN !== origin) { socket.destroy(); return; }
    } catch { socket.destroy(); return; }
  }
  wss.handleUpgrade(request, socket, head, (ws) => {
    ws.sessionId = sessionId;
    ws.clientId = clientId;
    if (!websocketClients.has(sessionId)) websocketClients.set(sessionId, new Set());
    websocketClients.get(sessionId).add(ws);
    ensureScene(sessionId);
    ws.send(JSON.stringify({ type: 'sync:ready', updatedAt: sceneStore.get(sessionId).updatedAt }));
    ws.on('close', () => {
      websocketClients.get(sessionId)?.delete(ws);
      if (websocketClients.get(sessionId)?.size === 0) websocketClients.delete(sessionId);
    });
  });
});

const vec3 = z.tuple([z.number().finite(), z.number().finite(), z.number().finite()]);
const positiveDimension = z.number().min(0.001).max(10000);
const sizeValue = z.union([z.tuple([positiveDimension, positiveDimension, positiveDimension]), z.tuple([positiveDimension, positiveDimension])]);
const matInput = z.object({
  name: z.string().max(80).optional(), color: z.string().optional(), metalness: z.number().min(0).max(1).optional(),
  roughness: z.number().min(0).max(1).optional(), opacity: z.number().min(0).max(1).optional(),
  transparent: z.boolean().optional(), emissive: z.string().optional(), emissiveIntensity: z.number().min(0).max(20).optional(),
  wireframe: z.boolean().optional()
}).strict();
const objectInput = z.object({
  type: z.enum(['box', 'sphere', 'cylinder', 'cone', 'torus', 'capsule', 'plane', 'circle', 'ring']),
  name: z.string().max(80).optional(), position: vec3.optional(), rotation: vec3.optional(), scale: vec3.optional(),
  size: sizeValue.optional(), radius: positiveDimension.optional(),
  radiusTop: z.number().min(0.001).max(10000).optional(), radiusBottom: z.number().min(0.001).max(10000).optional(),
  height: positiveDimension.optional(), tube: positiveDimension.optional(),
  innerRadius: positiveDimension.optional(), outerRadius: positiveDimension.optional(),
  material: matInput.optional(), castShadow: z.boolean().optional(), receiveShadow: z.boolean().optional()
}).strict();
const lookupInput = z.object({ objectId: z.string().max(100).optional(), name: z.string().max(80).optional() }).strict();
const transformInput = lookupInput.extend({ position: vec3.optional(), rotation: vec3.optional(), scale: vec3.optional() }).strict().refine((value) => value.position || value.rotation || value.scale, 'Provide at least one transform property.');
const toolName = (type) => type;

function textResult(value, isError = false) {
  return { content: [{ type: 'text', text: typeof value === 'string' ? value : JSON.stringify(value, null, 2) }], isError };
}
function targetName(args) { return args.objectId || args.name; }
function registerMcpTools(server, sessionId) {
  const readScene = () => ensureScene(sessionId).scene;
  const write = (fn, message) => {
    try {
      const { scene, result } = mutateScene(sessionId, fn, { source: 'mcp', recordUndo: true });
      return textResult({ success: true, sceneId: sessionId, message, ...(result ? { result } : {}), objectCount: countObjects(scene) });
    } catch (error) { return textResult({ success: false, error: { code: 'INVALID_ARGUMENT', message: error.message } }, true); }
  };
  server.registerTool('get_scene', {
    title: 'Get scene', description: 'Read the active AI 3D Studio scene, including hierarchy, environment, and object transforms.', inputSchema: z.object({}).strict()
  }, async () => textResult({ sceneId: sessionId, scene: readScene(), objectCount: countObjects(readScene()) }));
  server.registerTool('list_objects', {
    title: 'List objects', description: 'List all objects and their parent relationships in the active scene.', inputSchema: z.object({ query: z.string().max(80).optional() }).strict()
  }, async ({ query }) => {
    let objects = flattenObjects(readScene());
    if (query) objects = objects.filter((item) => item.name.toLowerCase().includes(query.toLowerCase()) || item.type.toLowerCase().includes(query.toLowerCase()));
    return textResult({ sceneId: sessionId, count: objects.length, objects });
  });
  server.registerTool('get_object', {
    title: 'Get object', description: 'Read one object by its ID or exact name.', inputSchema: lookupInput
  }, async (args) => {
    const node = findNode(readScene(), targetName(args));
    return node ? textResult(node) : textResult({ success: false, error: 'Object not found.' }, true);
  });
  server.registerTool('get_selected_object', {
    title: 'Get selected object', description: 'Read the object currently selected in the browser editor.', inputSchema: z.object({}).strict()
  }, async () => {
    const id = selectionByScene.get(sessionId);
    const node = findNode(readScene(), id);
    return node ? textResult(node) : textResult({ selected: false, message: 'No object is currently selected.' });
  });
  server.registerTool('create_scene', {
    title: 'Create scene', description: 'Create or replace the active scene with a clean scene shell.', inputSchema: z.object({ name: z.string().min(1).max(80) }).strict()
  }, async ({ name }) => write((scene) => Object.assign(scene, createScene(name)), `Created scene "${name}".`));
  server.registerTool('clear_scene', {
    title: 'Clear scene', description: 'Remove all objects and materials from the active scene.', inputSchema: z.object({}).strict()
  }, async () => write((scene) => { scene.objects = []; scene.materials = []; }, 'Cleared the scene.'));
  server.registerTool('add_object', {
    title: 'Add object', description: 'Add one validated primitive to the active scene. Coordinates are in meters; rotations are radians.', inputSchema: objectInput
  }, async (args) => write((scene) => addNode(scene, createNode(args.type, args)), `Added ${args.name || args.type}.`));
  server.registerTool('update_object', {
    title: 'Update object', description: 'Update an object name, visibility, geometry dimensions, or material by ID or exact name.',
    inputSchema: lookupInput.extend({ newName: z.string().max(80).optional(), visible: z.boolean().optional(), material: matInput.optional(), size: sizeValue.optional(), radius: positiveDimension.optional(), height: positiveDimension.optional() }).strict()
  }, async (args) => write((scene) => {
    const node = findNode(scene, targetName(args)); if (!node) throw new Error(`Object "${targetName(args)}" was not found.`);
    if (args.newName) node.name = args.newName;
    if (args.visible != null) node.visible = args.visible;
    if (args.material) node.material = args.material;
    if (args.size) node.size = args.size;
    if (args.radius) node.radius = args.radius;
    if (args.height) node.height = args.height;
    return node;
  }, `Updated ${targetName(args)}.`));
  server.registerTool('set_transform', {
    title: 'Set transform', description: 'Set position, rotation, and/or scale for an object.', inputSchema: transformInput
  }, async (args) => write((scene) => updateNode(scene, targetName(args), args), `Updated transform for ${targetName(args)}.`));
  server.registerTool('set_material', {
    title: 'Set material', description: 'Set PBR material properties on an object. Supported: color, metalness, roughness, opacity, transparency, emissive.',
    inputSchema: lookupInput.extend({ material: matInput }).strict()
  }, async (args) => write((scene) => updateNode(scene, targetName(args), { material: args.material }), `Updated material for ${targetName(args)}.`));
  server.registerTool('delete_object', {
    title: 'Delete object', description: 'Delete an object and its descendants by ID or exact name.', inputSchema: lookupInput
  }, async (args) => write((scene) => { if (!removeNode(scene, targetName(args))) throw new Error(`Object "${targetName(args)}" was not found.`); }, `Deleted ${targetName(args)}.`));
  server.registerTool('duplicate_object', {
    title: 'Duplicate object', description: 'Create a copy of an object or group, including its descendants.', inputSchema: lookupInput.extend({ offset: vec3.optional() }).strict()
  }, async (args) => write((scene) => { const copy = duplicateNode(scene, targetName(args)); if (args.offset) copy.position = args.offset; return copy; }, `Duplicated ${targetName(args)}.`));
  server.registerTool('create_group', {
    title: 'Create group', description: 'Create an empty transform group in the active scene.', inputSchema: z.object({ name: z.string().min(1).max(80), position: vec3.optional(), rotation: vec3.optional(), scale: vec3.optional() }).strict()
  }, async (args) => write((scene) => addNode(scene, createNode('group', args)), `Created group ${args.name}.`));
  server.registerTool('add_to_group', {
    title: 'Add object to group', description: 'Create a primitive as a child of an existing group.', inputSchema: objectInput.extend({ parentId: z.string().max(100) }).strict()
  }, async (args) => write((scene) => addNode(scene, createNode(args.type, args), args.parentId), `Added ${args.name || args.type} to ${args.parentId}.`));
  server.registerTool('add_light', {
    title: 'Add light', description: 'Add a directional, point, spot, or hemisphere light.', inputSchema: z.object({ type: z.enum(['directionalLight', 'pointLight', 'spotLight', 'hemisphereLight']), name: z.string().max(80).optional(), color: z.string().optional(), groundColor: z.string().optional(), intensity: z.number().min(0).max(1000).optional(), position: vec3.optional(), target: vec3.optional(), castShadow: z.boolean().optional() }).strict()
  }, async (args) => write((scene) => addNode(scene, createNode(args.type, args)), `Added ${args.name || args.type}.`));
  server.registerTool('set_environment', {
    title: 'Set environment', description: 'Update background, fog, grid, ground, and environment intensity.', inputSchema: z.object({ background: z.string().optional(), fog: z.object({ color: z.string().optional(), near: z.number().min(0).optional(), far: z.number().positive().optional() }).strict().optional(), grid: z.boolean().optional(), ground: z.boolean().optional(), intensity: z.number().min(0).max(4).optional() }).strict()
  }, async (args) => write((scene) => {
    const commands = [{ name: 'environment', args: [args] }];
    const updated = applySceneCommands(scene, commands);
    Object.assign(scene, updated);
  }, 'Updated the environment.'));
  server.registerTool('run_scene_code', {
    title: 'Run scene code', description: 'Parse, validate, and run AI 3D Studio literal Scene API code. Arbitrary JavaScript is never executed.', inputSchema: z.object({ code: z.string().min(1).max(50000), replace: z.boolean().default(true) }).strict()
  }, async ({ code, replace }) => {
    try {
      const commands = parseSceneCode(code);
      return write((scene) => {
        const updated = applySceneCommands(replace ? createScene(scene.scene?.name || 'AI Scene') : scene, commands);
        Object.assign(scene, updated);
      }, `Applied ${commands.length} validated scene command${commands.length === 1 ? '' : 's'}.`);
    } catch (error) { return textResult({ success: false, error: { code: 'SCENE_CODE_ERROR', message: error.message } }, true); }
  });
  server.registerTool('undo', {
    title: 'Undo', description: 'Undo the last scene edit in this scene session.', inputSchema: z.object({}).strict()
  }, async () => {
    const record = ensureScene(sessionId);
    if (!record.history.length) return textResult({ success: false, message: 'Nothing to undo.' });
    record.redo.push(cloneValue(record.scene));
    record.scene = record.history.pop();
    record.updatedAt = new Date().toISOString();
    sendToScene(sessionId, { type: 'scene:update', scene: record.scene, source: 'mcp', updatedAt: record.updatedAt });
    return textResult({ success: true, message: 'Undid the last edit.', objectCount: countObjects(record.scene) });
  });
  server.registerTool('redo', {
    title: 'Redo', description: 'Redo the last undone scene edit.', inputSchema: z.object({}).strict()
  }, async () => {
    const record = ensureScene(sessionId);
    if (!record.redo.length) return textResult({ success: false, message: 'Nothing to redo.' });
    record.history.push(cloneValue(record.scene));
    record.scene = record.redo.pop();
    record.updatedAt = new Date().toISOString();
    sendToScene(sessionId, { type: 'scene:update', scene: record.scene, source: 'mcp', updatedAt: record.updatedAt });
    return textResult({ success: true, message: 'Redid the last edit.', objectCount: countObjects(record.scene) });
  });
  server.registerTool('export_scene', {
    title: 'Export scene data', description: 'Return scene JSON or AI 3D Studio Scene API code. Use the browser toolbar for GLB/glTF export.', inputSchema: z.object({ format: z.enum(['json', 'scene-code']).default('json') }).strict()
  }, async ({ format }) => {
    const scene = readScene();
    return format === 'scene-code' ? textResult({ format, sceneCode: (await import('./shared/scene-core.js')).sceneToCode(scene) }) : textResult({ format, scene });
  });
}

app.all('/mcp', async (req, res) => {
  if (!safeAuth(req, res)) return;
  const sceneSessionId = getSessionId(req);
  if (!sceneSessionId) return res.status(400).json({ error: 'A valid sceneId is required in the MCP URL: /mcp?sessionId=<scene-session-id>.' });
  ensureScene(sceneSessionId);
  const protocolSessionId = req.headers['mcp-session-id'];
  let session = protocolSessionId ? protocolSessions.get(String(protocolSessionId)) : null;
  if (protocolSessionId && !session) return res.status(404).json({ error: 'MCP session not found. Reconnect to the server.' });
  if (!session && req.method !== 'POST') return res.status(400).json({ error: 'Initialize an MCP session with POST first.' });
  if (!session) {
    const server = new McpServer({ name: 'ai-3d-studio', version: '0.1.0' });
    registerMcpTools(server, sceneSessionId);
    const transport = new StreamableHTTPServerTransport({
      sessionIdGenerator: () => randomUUID(),
      onsessioninitialized: (id) => protocolSessions.set(id, { server, transport, sceneSessionId })
    });
    transport.onclose = () => {
      const id = transport.sessionId;
      if (id) protocolSessions.delete(id);
      void server.close();
    };
    session = { server, transport, sceneSessionId };
    try {
      await server.connect(transport);
    } catch (error) {
      return res.status(500).json({ error: 'Could not initialize MCP server.', details: error.message });
    }
  } else if (session.sceneSessionId !== sceneSessionId) {
    return res.status(403).json({ error: 'MCP session is scoped to a different scene.' });
  }
  try {
    await session.transport.handleRequest(req, res, req.method === 'POST' ? req.body : undefined);
  } catch (error) {
    if (!res.headersSent) res.status(500).json({ error: 'MCP request failed.', details: error.message });
  }
});

app.get('/api/mcp/tools', (_req, res) => res.json({ tools: ['get_scene', 'list_objects', 'get_object', 'get_selected_object', 'create_scene', 'clear_scene', 'add_object', 'update_object', 'set_transform', 'set_material', 'delete_object', 'duplicate_object', 'create_group', 'add_to_group', 'add_light', 'set_environment', 'run_scene_code', 'undo', 'redo', 'export_scene'] }));

if (production) {
  const dist = join(root, 'dist');
  if (existsSync(dist)) {
    app.use(express.static(dist, { index: false, maxAge: '1h' }));
    app.get(/.*/, (_req, res) => res.sendFile(join(dist, 'index.html')));
  }
} else {
  const { createServer: createViteServer } = await import('vite');
  const vite = await createViteServer({
    root,
    server: { middlewareMode: true, hmr: { server: httpServer }, allowedHosts: true },
    appType: 'spa'
  });
  app.use(vite.middlewares);
}

httpServer.listen(PORT, '0.0.0.0', () => {
  console.log(`AI 3D Studio running at http://0.0.0.0:${PORT}`);
  console.log(`Streamable HTTP MCP endpoint: http://0.0.0.0:${PORT}/mcp?sessionId=<scene-session-id>`);
  if (!process.env.MCP_API_TOKEN) console.warn('MCP_API_TOKEN is not set: development mode uses unguessable per-scene capability URLs; configure a bearer token before internet-facing deployment.');
});
