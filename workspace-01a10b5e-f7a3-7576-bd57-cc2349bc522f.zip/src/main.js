import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { TransformControls } from 'three/addons/controls/TransformControls.js';
import { GLTFExporter } from 'three/addons/exporters/GLTFExporter.js';
import {
  API_REFERENCE, LIGHT_TYPES, MASTER_PROMPT, PRIMITIVE_TYPES, addNode, applySceneCommands,
  cloneValue, countObjects, createId, createNode, createScene, findNode, flattenObjects,
  formatSceneCode, normalizeSceneData, parseSceneCode, sceneToCode, updateNode, walkNodes
} from '../shared/scene-core.js';
import './styles.css';

const iconPaths = {
  logo: '<path d="M5 18 12 5l7 13M8 13h8"/><path d="M7 20h10"/>',
  file: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M8 13h8M8 17h5"/>',
  folder: '<path d="M3 7a2 2 0 0 1 2-2h5l2 2h7a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M3 10h18"/>',
  save: '<path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2Z"/><path d="M17 21v-8H7v8M7 3v5h8"/>',
  undo: '<path d="M3 7v6h6"/><path d="M4.5 13a8 8 0 1 0 2-6L3 10"/>',
  redo: '<path d="M21 7v6h-6"/><path d="M19.5 13a8 8 0 1 1-2-6L21 10"/>',
  play: '<path d="m8 5 12 7-12 7z" fill="currentColor" stroke="none"/>',
  export: '<path d="M12 15V3m0 0L8 7m4-4 4 4"/><path d="M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-7"/>',
  chevron: '<path d="m9 18 6-6-6-6"/>',
  down: '<path d="m6 9 6 6 6-6"/>',
  scene: '<path d="m12 3 9 5-9 5-9-5 9-5Z"/><path d="m3 12 9 5 9-5M3 16l9 5 9-5"/>',
  guide: '<path d="m12 3 1.7 5.3L19 10l-5.3 1.7L12 17l-1.7-5.3L5 10l5.3-1.7L12 3Z"/><path d="m19 15 .8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8L19 15Z"/>',
  mcp: '<path d="M8 5a2.5 2.5 0 1 0-2.5 2.5H8V5ZM8 5v14a2.5 2.5 0 1 0 2.5-2.5H8"/><path d="M16 5a2.5 2.5 0 1 1 2.5 2.5H16V5ZM16 5v7a2.5 2.5 0 1 0 2.5-2.5H16"/>',
  docs: '<path d="M4 4.5A2.5 2.5 0 0 1 6.5 2H20v18H6.5A2.5 2.5 0 0 0 4 22z"/><path d="M4 4v16M8 6h8M8 10h8M8 14h6"/>',
  search: '<circle cx="10.8" cy="10.8" r="6.3"/><path d="m16 16 4.5 4.5"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/>',
  eyeOff: '<path d="m3 3 18 18M10.6 10.6a2 2 0 0 0 2.8 2.8"/><path d="M9.9 5.2A11 11 0 0 1 12 5c6.5 0 10 7 10 7a17 17 0 0 1-4.2 4.8M6.2 6.2C3.4 8 2 12 2 12s3.5 7 10 7c1.2 0 2.3-.2 3.3-.6"/>',
  box: '<path d="m12 3 9 5-9 5-9-5 9-5Z"/><path d="M3 8v9l9 5 9-5V8M12 13v9"/>',
  cube: '<path d="m12 3 8.5 4.5v9L12 21l-8.5-4.5v-9L12 3Z"/><path d="m3.8 7.6 8.2 4.6 8.2-4.6M12 12.2V21"/>',
  sphere: '<circle cx="12" cy="12" r="8.5"/><path d="M4.5 9.5h15M4.5 14.5h15M12 3.5c2.7 2.3 4.1 5.1 4.1 8.5s-1.4 6.2-4.1 8.5c-2.7-2.3-4.1-5.1-4.1-8.5S9.3 5.8 12 3.5Z"/>',
  move: '<path d="M12 3v18M3 12h18M12 3l-3 3m3-3 3 3M12 21l-3-3m3 3 3-3M3 12l3-3m-3 3 3 3m15-3-3-3m3 3-3 3"/>',
  rotate: '<path d="M20.5 8A8.5 8.5 0 0 0 5 5.2L3 8"/><path d="M3 3v5h5M3.5 16A8.5 8.5 0 0 0 19 18.8L21 16"/><path d="M21 21v-5h-5"/>',
  scale: '<path d="M4 9V4h5M20 15v5h-5M4 4l6 6m10 10-6-6M15 4h5v5M4 15v5h5M20 4l-6 6M4 20l6-6"/>',
  focus: '<circle cx="12" cy="12" r="7"/><path d="M12 2v5m0 10v5M2 12h5m10 0h5"/>',
  trash: '<path d="M3 6h18M8 6V4h8v2m3 0-1 14H6L5 6m4 4v7m6-7v7"/>',
  copy: '<rect x="8" y="8" width="13" height="13" rx="2"/><path d="M16 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h3"/>',
  download: '<path d="M12 3v12m0 0 4-4m-4 4-4-4"/><path d="M4 16v4a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-4"/>',
  check: '<path d="m5 12 4 4L19 6"/>',
  close: '<path d="m18 6-12 12M6 6l12 12"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5m0-8h.01"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2m0 16v2M4.9 4.9l1.4 1.4m11.4 11.4 1.4 1.4M2 12h2m16 0h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  layers: '<path d="m12 3 9 5-9 5-9-5 9-5Z"/><path d="m3 12 9 5 9-5M3 16l9 5 9-5"/>',
  camera: '<path d="M4 7h3l2-2h6l2 2h3v12H4z"/><circle cx="12" cy="13" r="4"/>',
  settings: '<circle cx="12" cy="12" r="3"/><path d="m19.4 15 .1.1 1.4 1.1-1.5 2.6-1.7-.7a8 8 0 0 1-1.5.9l-.3 1.9h-3l-.3-1.9a8 8 0 0 1-1.5-.9l-1.7.7-1.5-2.6 1.4-1.1a7 7 0 0 1 0-1.8l-1.4-1.1 1.5-2.6 1.7.7a8 8 0 0 1 1.5-.9l.3-1.9h3l.3 1.9a8 8 0 0 1 1.5.9l1.7-.7 1.5 2.6-1.4 1.1a7 7 0 0 1-.1 1.8Z"/>',
  sparkle: '<path d="m12 3 1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8L12 3Z"/><path d="m19 15 .6 1.8L21.5 17l-1.9.6L19 19.5l-.6-1.9-1.9-.6 1.9-.2L19 15Z"/>',
  menu: '<path d="M4 6h16M4 12h16M4 18h16"/>',
  more: '<circle cx="5" cy="12" r="1" fill="currentColor"/><circle cx="12" cy="12" r="1" fill="currentColor"/><circle cx="19" cy="12" r="1" fill="currentColor"/>',
  cloud: '<path d="M7 18H6a4 4 0 1 1 1-7.9A5.5 5.5 0 0 1 17.8 9 4.5 4.5 0 1 1 18 18H7Z"/>',
  checkCircle: '<circle cx="12" cy="12" r="9"/><path d="m8 12 2.5 2.5L16 9"/>',
  alert: '<path d="m12 3 10 18H2L12 3Z"/><path d="M12 9v5m0 3h.01"/>',
  tune: '<path d="M4 6h16M4 12h16M4 18h16"/><circle cx="9" cy="6" r="2" fill="#0d1520"/><circle cx="15" cy="12" r="2" fill="#0d1520"/><circle cx="11" cy="18" r="2" fill="#0d1520"/>',
  material: '<path d="m12 3 9 5v8l-9 5-9-5V8l9-5Z"/><path d="m3 8 9 5 9-5M12 13v8"/>',
  grid: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',
  github: '<path d="M9 19c-4.3 1.4-4.3-2.5-6-3m12 6v-3.9a3.4 3.4 0 0 0-.9-2.7c3-.3 6.2-1.5 6.2-6.8A5.3 5.3 0 0 0 19 5a4.9 4.9 0 0 0-.1-3S17.7 1.7 15 3.5a13.3 13.3 0 0 0-7 0C5.3 1.7 4.1 2 4.1 2A4.9 4.9 0 0 0 4 5a5.3 5.3 0 0 0-1.3 3.7c0 5.3 3.2 6.5 6.2 6.8A3.4 3.4 0 0 0 8 18.2V22"/>',
  cubeSmall: '<path d="m12 3 8 4.5v9L12 21l-8-4.5v-9L12 3Z"/><path d="m4.5 7.7 7.5 4.2 7.5-4.2M12 12v9"/>'
};
function icon(name, size = 16) { return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${iconPaths[name] || iconPaths.cubeSmall}</svg>`; }
function escapeHtml(value) { return String(value ?? '').replace(/[&<>"']/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char])); }
function fmt(value, digits = 2) { const n = Number(value); return Number.isFinite(n) ? n.toFixed(digits) : '0.00'; }
function niceName(value) { return String(value || '').replace(/([a-z])([A-Z])/g, '$1 $2').replace(/^./, (m) => m.toUpperCase()); }

const app = document.querySelector('#app');
const storageFallback = new Map();
function storageGet(key) { try { return window.localStorage.getItem(key); } catch { return storageFallback.get(key) || null; } }
function storageSet(key, value) { const stringValue = String(value); storageFallback.set(key, stringValue); try { window.localStorage.setItem(key, stringValue); } catch {} }
let sceneData = createScene('Alpine Glass House');
let sessionId = storageGet('a3d-session-id');
if (!sessionId) { sessionId = `studio_${createId('session').replace(/[^a-zA-Z0-9_-]/g, '')}`; storageSet('a3d-session-id', sessionId); }
const clientId = `browser_${createId('client').replace(/[^a-zA-Z0-9_-]/g, '')}`;
let ws = null;
let wsStatus = 'connecting';
let currentSection = 'scene';
let inspectorTab = 'inspector';
let selectedId = null;
let expandedIds = new Set();
let undoStack = [];
let redoStack = [];
let historyLimit = 40;
let codeDirty = false;
let codeExpanded = false;
let searchTerm = '';
let mcpServerOnline = false;
let currentToolMode = 'translate';
let cameraPresetIndex = 0;
let worldRoot, scene3d, camera3d, renderer, orbitControls, transformControls, transformHelper, selectionBox, gridHelper, axesHelper;
let objectMap = new Map();
let materialCache = new Map();
let raycaster = new THREE.Raycaster();
let pointerDown = null;
let transformStartSnapshot = null;
let lastFrameTime = performance.now();
let frameCount = 0;
let fps = 60;
let lastCommitLabel = 'Saved';
let saveTimer;

function createDemoScene() {
  const s = createScene('Alpine Glass House');
  s.environment = { background: '#b7c9d4', fog: { color: '#bdced4', near: 65, far: 185 }, ground: true, grid: false, intensity: 1.08 };
  s.camera = { position: [18.5, 12.8, 21.5], target: [0, 2.65, 0], fov: 41 };
  s.materials = [
    { name: 'Warm Limestone', color: '#c8b9a0', metalness: 0.04, roughness: 0.9 },
    { name: 'Ivory Stucco', color: '#e7e2d8', metalness: 0.02, roughness: 0.82 },
    { name: 'Weathered Oak', color: '#805535', metalness: 0.02, roughness: 0.63 },
    { name: 'Oiled Walnut', color: '#4c3023', metalness: 0.03, roughness: 0.5 },
    { name: 'Slate Roof', color: '#303d49', metalness: 0.24, roughness: 0.35 },
    { name: 'Graphite Frame', color: '#1d2a33', metalness: 0.65, roughness: 0.3 },
    { name: 'Lake Glass', color: '#a9d8df', metalness: 0.18, roughness: 0.14, opacity: 0.42, transparent: true },
    { name: 'Pine Needles', color: '#315a45', metalness: 0, roughness: 0.9 },
    { name: 'Deep Evergreen', color: '#244737', metalness: 0, roughness: 0.94 },
    { name: 'Mountain Meadow', color: '#637b5a', metalness: 0, roughness: 1 },
    { name: 'River Stone', color: '#807e75', metalness: 0.04, roughness: 0.93 },
    { name: 'Blue Water', color: '#6697a0', metalness: 0.22, roughness: 0.2 },
    { name: 'Soft Gold', color: '#d9a866', metalness: 0.72, roughness: 0.25 },
    { name: 'Warm Linen', color: '#c7ad8b', metalness: 0, roughness: 0.88 },
    { name: 'Garden Moss', color: '#65784c', metalness: 0, roughness: 0.98 },
    { name: 'Cloud Ivory', color: '#f4f0e5', metalness: 0, roughness: 1 }
  ];
  const node = (type, props) => createNode(type, props);
  const add = (parent, type, props) => { const child = node(type, props); parent.children.push(child); return child; };
  const group = (name, position = [0, 0, 0]) => node('group', { name, position });

  const house = group('House');
  const h = (name, size, position, material, extras = {}) => add(house, 'box', { name, size, position, material, ...extras });
  h('Stone foundation', [12.2, 0.42, 8.4], [0, 0.21, 0], 'Warm Limestone');
  h('Ground floor oak deck', [11.8, 0.12, 8], [0, 0.48, 0], 'Weathered Oak');
  h('Lower rear wall', [11.1, 3.15, 0.24], [0, 2.03, -3.78], 'Ivory Stucco');
  h('Lower west wall', [0.25, 3.15, 7.5], [-5.46, 2.03, 0], 'Ivory Stucco');
  h('Lower east wall', [0.25, 3.15, 7.5], [5.46, 2.03, 0], 'Warm Limestone');
  h('Lower front glass panel 01', [2.42, 2.72, 0.07], [-3.63, 1.94, 3.72], 'Lake Glass', { castShadow: false, receiveShadow: false });
  h('Lower front glass panel 02', [2.42, 2.72, 0.07], [-1.19, 1.94, 3.72], 'Lake Glass', { castShadow: false, receiveShadow: false });
  h('Lower front glass panel 03', [2.42, 2.72, 0.07], [1.25, 1.94, 3.72], 'Lake Glass', { castShadow: false, receiveShadow: false });
  h('Lower front glass panel 04', [2.42, 2.72, 0.07], [3.69, 1.94, 3.72], 'Lake Glass', { castShadow: false, receiveShadow: false });
  [-4.86, -2.42, 0.02, 2.46, 4.9].forEach((x, i) => h(`Lower mullion ${i + 1}`, [0.075, 2.92, 0.12], [x, 1.94, 3.78], 'Graphite Frame'));
  h('Lower sill', [10.3, 0.1, 0.15], [0, 0.59, 3.8], 'Graphite Frame');
  h('Lower transom', [10.3, 0.08, 0.14], [0, 3.22, 3.8], 'Graphite Frame');
  h('Great room sofa base', [3.2, 0.54, 1.1], [-1.25, 0.91, 0.75], 'Warm Linen');
  h('Great room sofa back', [3.2, 0.82, 0.22], [-1.25, 1.56, 0.2], 'Warm Linen');
  h('Coffee table top', [1.8, 0.12, 0.92], [1.45, 0.98, 0.6], 'Weathered Oak');
  h('Coffee table pedestal', [0.16, 0.43, 0.16], [1.45, 0.7, 0.6], 'Graphite Frame');
  h('Kitchen island', [2.7, 0.92, 0.85], [2.95, 1.02, -1.45], 'Warm Limestone');
  h('Island oak top', [2.88, 0.11, 0.98], [2.95, 1.54, -1.45], 'Weathered Oak');
  h('Dining table', [2.35, 0.13, 1.12], [-2.95, 1.06, -1.55], 'Weathered Oak');
  [-3.85, -2.05].forEach((x, i) => h(`Dining chair ${i + 1}`, [0.46, 0.88, 0.46], [x, 0.96, -0.55], 'Oiled Walnut'));
  h('Upper floor floating slab', [12.9, 0.32, 9.1], [0, 3.63, -0.05], 'Graphite Frame');
  h('Upper floor oak finish', [11.9, 0.11, 8], [0, 3.84, -0.08], 'Weathered Oak');
  h('Upper rear wall', [9.7, 2.68, 0.22], [0, 5.22, -3.56], 'Ivory Stucco');
  h('Upper west wall', [0.22, 2.68, 6.8], [-4.84, 5.22, -0.15], 'Ivory Stucco');
  h('Upper east wall', [0.22, 2.68, 6.8], [4.84, 5.22, -0.15], 'Ivory Stucco');
  h('Upper front glass left', [3.04, 2.36, 0.065], [-3.05, 5.14, 3.23], 'Lake Glass', { castShadow: false, receiveShadow: false });
  h('Upper front glass center', [3.04, 2.36, 0.065], [0, 5.14, 3.23], 'Lake Glass', { castShadow: false, receiveShadow: false });
  h('Upper front glass right', [3.04, 2.36, 0.065], [3.05, 5.14, 3.23], 'Lake Glass', { castShadow: false, receiveShadow: false });
  [-4.62, -1.52, 1.52, 4.62].forEach((x, i) => h(`Upper mullion ${i + 1}`, [0.08, 2.6, 0.13], [x, 5.14, 3.29], 'Graphite Frame'));
  h('Upper window header', [9.9, 0.12, 0.18], [0, 6.43, 3.29], 'Graphite Frame');
  h('Roof timber soffit', [13.2, 0.12, 9.5], [0, 6.76, -0.12], 'Weathered Oak');
  h('Flat cantilever roof', [13.65, 0.3, 10], [0, 6.99, -0.12], 'Slate Roof', { rotation: [0, 0, -0.025] });
  h('Chimney stone stack', [1.12, 4.6, 1.1], [4.04, 5.02, -1.65], 'Warm Limestone');
  h('Chimney crown', [1.36, 0.22, 1.35], [4.04, 7.42, -1.65], 'Graphite Frame');
  h('Balcony glass guard', [8.9, 0.8, 0.08], [0, 4.36, 3.83], 'Lake Glass', { castShadow: false, receiveShadow: false });
  [-4.35, -2.2, 0, 2.2, 4.35].forEach((x, i) => h(`Balcony post ${i + 1}`, [0.06, 0.82, 0.11], [x, 4.38, 3.88], 'Graphite Frame'));
  h('Balcony top rail', [9.1, 0.09, 0.13], [0, 4.8, 3.88], 'Graphite Frame');
  h('Entry canopy', [3.1, 0.18, 1.7], [0, 3.45, 4.42], 'Weathered Oak');
  const steps = group('Stone entry steps');
  [[0, 0.17, 4.5], [0, 0.13, 5.08], [0, 0.09, 5.66], [0, 0.06, 6.24]].forEach((pos, i) => add(steps, 'box', { name: `Step ${i + 1}`, size: [2.7 - i * 0.1, 0.16, 0.7], position: pos, material: 'River Stone' }));
  house.children.push(steps);
  s.objects.push(house);

  const trees = group('Trees');
  const addTree = (x, z, height, label, variant = 0) => {
    const tree = group(label, [x, 0, z]);
    const trunkH = height * 0.38;
    add(tree, 'cylinder', { name: 'Trunk', radiusTop: 0.12, radiusBottom: 0.24, height: trunkH, position: [0, trunkH / 2, 0], material: 'Oiled Walnut', radialSegments: 9 });
    const layers = 3;
    for (let i = 0; i < layers; i++) {
      const sectionH = height * (0.46 - i * 0.06);
      const radius = height * (0.23 - i * 0.035);
      add(tree, 'cone', { name: `Evergreen crown ${i + 1}`, radius, height: sectionH, position: [0, trunkH + sectionH * 0.38 + i * height * 0.21, 0], material: variant % 2 ? 'Deep Evergreen' : 'Pine Needles', radialSegments: 8 });
    }
    trees.children.push(tree);
  };
  addTree(-10.5, -1.5, 6.8, 'Pine 01', 0);
  addTree(-12.8, -7.5, 7.8, 'Pine 02', 1);
  addTree(9.5, -7.4, 6.5, 'Pine 03', 0);
  addTree(12.2, -0.8, 7.8, 'Pine 04', 1);
  addTree(-8.7, 7.2, 5.7, 'Pine 05', 1);
  addTree(9.5, 8.3, 6.3, 'Pine 06', 0);
  addTree(-16, -12, 8.4, 'Pine 07', 0);
  addTree(15.3, -12.8, 7.5, 'Pine 08', 1);
  s.objects.push(trees);

  const terrain = group('Landscape');
  add(terrain, 'plane', { name: 'Meadow ground', size: [160, 160], position: [0, -0.055, 0], material: 'Mountain Meadow', receiveShadow: true, castShadow: false });
  add(terrain, 'plane', { name: 'Quiet lake', size: [34, 21], position: [-11.5, 0.08, -18.8], rotation: [0.012, -0.18, 0], material: 'Blue Water', receiveShadow: false, castShadow: false });
  const hills = group('Alpine ridgeline');
  [[-21, 5.8, -24, 15, 12], [-12, 8.2, -28, 18, 15], [-1, 6.2, -31, 14, 11], [10, 8, -30, 18, 15], [22, 6.5, -25, 16, 12], [-28, 4.8, -17, 13, 10], [29, 5.5, -19, 14, 11]].forEach((m, i) => {
    add(hills, 'cone', { name: `Mountain peak ${i + 1}`, radius: m[3], height: m[4], position: [m[0], m[1], m[2]], material: i % 2 ? 'River Stone' : 'Warm Limestone', radialSegments: 7 });
    if (i % 2 === 0) add(hills, 'cone', { name: `Snow ridge ${i + 1}`, radius: m[3] * 0.43, height: m[4] * 0.52, position: [m[0] - 1.2, m[1] + m[4] * 0.25, m[2] + 0.2], material: 'Cloud Ivory', radialSegments: 7 });
  });
  terrain.children.push(hills);
  const clouds = group('High clouds');
  [[-16, 13, -27, 5.3], [4, 15, -32, 4.5], [20, 12.5, -24, 5.5]].forEach((c, i) => {
    const cloud = group(`Cloud ${i + 1}`, [c[0], c[1], c[2]]);
    [[0, 0, 0, 1], [1.6, 0.35, 0, 0.72], [-1.5, 0.25, 0.2, 0.82]].forEach((p, j) => add(cloud, 'sphere', { name: `Cloud puff ${j + 1}`, radius: c[3] * p[3], position: [p[0], p[1], p[2]], scale: [1.35, 0.34, 0.58], material: 'Cloud Ivory', castShadow: false, receiveShadow: false }));
    clouds.children.push(cloud);
  });
  terrain.children.push(clouds);
  s.objects.push(terrain);

  const rocks = group('Rocks & meadow');
  const rockSites = [[-7.8, 5.8, .65], [-6.2, 7.6, .48], [6.6, 7.5, .7], [8.2, 5.4, .48], [-5.4, 10.2, .6], [5.6, 10.5, .62], [-9.8, -3.2, .68], [10.5, -3.8, .75], [-2.7, 8.8, .42], [3.4, 8.6, .4], [-12, 3.8, .7], [13, 3, .65], [-4.5, 13, .45], [4.4, 13, .45], [-1.1, 15, .55], [2, 15.7, .4]];
  rockSites.forEach((p, i) => add(rocks, 'sphere', { name: `Granite boulder ${String(i + 1).padStart(2, '0')}`, radius: p[2], position: [p[0], p[2] * 0.58, p[1]], scale: [1.35, 0.78 + (i % 3) * 0.08, 1.05], material: i % 4 === 0 ? 'Warm Limestone' : 'River Stone', widthSegments: 9, heightSegments: 6 }));
  const shrubs = group('Alpine juniper');
  [[-7.6, 3, 1.1], [-6.6, 4.1, .8], [7.3, 2.8, .85], [8.2, 3.8, .8], [-10, 5, .95], [10.5, 5, .85], [-3, 11.2, .7], [3.2, 12, .8]].forEach((p, i) => add(shrubs, 'sphere', { name: `Juniper ${i + 1}`, radius: p[2], position: [p[0], p[2] * 0.46, p[1]], scale: [1.4, 0.75, 1], material: i % 2 ? 'Deep Evergreen' : 'Pine Needles', widthSegments: 10, heightSegments: 7 }));
  rocks.children.push(shrubs);
  const flowers = group('Meadow flowers');
  const flowerColors = ['#e6c5bd', '#f0d27a', '#d9b6db', '#d9e2c5'];
  for (let i = 0; i < 27; i++) {
    const x = -11 + ((i * 17) % 220) / 10;
    const z = 8 + ((i * 31) % 105) / 10;
    if (Math.abs(x) < 6.8 && z < 12) continue;
    const flower = group(`Wildflower ${String(i + 1).padStart(2, '0')}`, [x, 0, z]);
    add(flower, 'cylinder', { name: 'Stem', radiusTop: .018, radiusBottom: .025, height: .34, position: [0, .17, 0], material: 'Pine Needles', radialSegments: 5, castShadow: false });
    add(flower, 'sphere', { name: 'Bloom', radius: .12, position: [0, .37, 0], scale: [1, .75, 1], material: { color: flowerColors[i % flowerColors.length], roughness: .7 }, widthSegments: 8, heightSegments: 6, castShadow: false });
    flowers.children.push(flower);
  }
  rocks.children.push(flowers);
  s.objects.push(rocks);

  const path = group('Garden path');
  [[0, .11, 6.8], [.15, .1, 8.2], [-.12, .1, 9.6], [.2, .09, 11], [0, .08, 12.4], [-.1, .07, 13.8]].forEach((pos, i) => add(path, 'box', { name: `Path paver ${i + 1}`, size: [2.25 - i * .08, .12, .85], position: pos, rotation: [0, (i % 2 ? .04 : -.06), 0], material: 'River Stone' }));
  s.objects.push(path);

  const lights = group('Lights');
  lights.children.push(node('hemisphereLight', { name: 'Sky fill', skyColor: '#d9e8f2', groundColor: '#60584a', intensity: 0.9, position: [0, 15, 0] }));
  lights.children.push(node('directionalLight', { name: 'Golden hour sun', color: '#ffe1bc', intensity: 2.8, position: [-9, 17, 11], castShadow: true }));
  lights.children.push(node('pointLight', { name: 'Interior glow', color: '#ffb969', intensity: 26, distance: 13, decay: 2, position: [0, 2.1, 0.5] }));
  lights.children.push(node('pointLight', { name: 'Porch lantern', color: '#ffc882', intensity: 9, distance: 7, decay: 2, position: [0, 2.9, 4.7] }));
  s.objects.push(lights);
  return s;
}

function shellMarkup() {
  return `
  <div class="studio-shell">
    <header class="topbar">
      <div class="brand-lockup">
        <div class="brand-mark">A<span>3D</span></div>
        <div class="brand-copy"><strong>AI 3D STUDIO</strong><span>AI-powered creation</span></div>
        <span class="top-divider"></span>
        <span class="product-chip">PROCEDURAL WORKSPACE <i></i></span>
      </div>
      <div class="main-actions">
        <button class="top-action" data-action="new" title="New scene">${icon('file', 15)}<span>New</span></button>
        <button class="top-action" data-action="open" title="Open project">${icon('folder', 15)}<span>Open</span></button>
        <button class="top-action" data-action="save" title="Save project">${icon('save', 15)}<span>Save</span></button>
        <span class="action-divider"></span>
        <button class="top-action icon-only" data-action="undo" title="Undo" aria-label="Undo">${icon('undo', 16)}</button>
        <button class="top-action icon-only" data-action="redo" title="Redo" aria-label="Redo">${icon('redo', 16)}</button>
        <button class="top-action run-action" data-action="run" title="Run scene code">${icon('play', 14)}<span>Run</span></button>
        <div class="export-wrap"><button class="top-action export-action" data-action="export-menu">${icon('export', 15)}<span>Export</span>${icon('down', 12)}</button><div class="export-menu hidden" id="export-menu"><button data-action="export-glb">${icon('cube', 15)}Export GLB</button><button data-action="export-json">${icon('file', 15)}Scene JSON</button><button data-action="export-code">${icon('download', 15)}Scene Code</button></div></div>
      </div>
      <div class="top-right-actions">
        <button class="connection-pill" data-action="open-mcp" title="MCP setup"><span class="connection-indicator"><i></i></span><span class="connection-text"><strong id="mcp-pill-title">MCP server</strong><small id="mcp-pill-state">Checking connection…</small></span><span class="connection-chevron">${icon('chevron', 13)}</span></button>
        <button class="profile-button" title="Workspace settings" data-action="settings">${icon('settings', 17)}</button>
      </div>
    </header>
    <div class="workspace">
      <aside class="left-panel panel-shell">
        <nav class="side-nav" aria-label="Studio sections">
          <button class="side-tab active" data-section="scene">${icon('scene', 17)}<span>Scene</span></button>
          <button class="side-tab" data-section="guide">${icon('guide', 17)}<span>AI Guide</span></button>
          <button class="side-tab" data-section="mcp">${icon('mcp', 17)}<span>MCP</span></button>
          <button class="side-tab" data-section="docs">${icon('docs', 17)}<span>Docs</span></button>
        </nav>
        <div class="left-content" id="left-content"></div>
      </aside>
      <main class="center-stage">
        <section class="viewport-card" id="viewport-card">
          <div id="viewport" class="viewport"></div>
          <div class="viewport-topbar">
            <div class="viewport-left-controls"><button class="mobile-panel-trigger" data-action="mobile-scene" title="Open scene hierarchy">${icon('layers', 14)}</button><button class="viewport-select" data-action="camera-menu">${icon('camera', 14)}<span>Perspective</span>${icon('down', 12)}</button></div>
            <div class="viewport-tools">
              <button class="view-tool" data-tool="translate" title="Move (W)">${icon('move', 15)}</button>
              <button class="view-tool" data-tool="rotate" title="Rotate (E)">${icon('rotate', 15)}</button>
              <button class="view-tool" data-tool="scale" title="Scale (R)">${icon('scale', 15)}</button>
              <span class="tool-divider"></span>
              <button class="view-tool" data-action="toggle-grid" title="Toggle grid">${icon('grid', 15)}</button>
              <button class="view-tool" data-action="frame-selected" title="Frame selected object">${icon('focus', 15)}</button>
              <button class="mobile-panel-trigger" data-action="mobile-inspector" title="Open inspector">${icon('tune', 14)}</button>
            </div>
          </div>
          <div class="camera-axis" aria-label="World axes"><span class="axis-y">Y</span><span class="axis-x">X</span><span class="axis-z">Z</span><i class="axis-dot"></i></div>
          <div class="viewport-bottom-left"><span class="live-dot"></span><span id="fps-label">60 FPS</span><span class="status-separator">·</span><span>Orbit to inspect</span></div>
          <div class="viewport-bottom-right"><span id="selection-count">0 objects</span><span class="status-separator">·</span><span>WebGL</span></div>
          <div class="viewport-empty hidden" id="viewport-empty"><div>${icon('cube', 27)}</div><strong>Nothing in the scene yet</strong><span>Add an object or run some scene code to get started.</span><button class="btn-primary small" data-action="add-cube">${icon('plus', 13)}Add cube</button></div>
        </section>
        <section class="code-dock" id="code-dock">
          <header class="code-dock-head">
            <div class="editor-title"><span class="code-title-icon">{ }</span><div><strong>AI Scene Code</strong><small>Safe, structured Scene API</small></div></div>
            <div class="editor-head-actions">
              <button class="mini-action primary-mini" data-action="run">${icon('play', 12)}Run</button>
              <button class="mini-action" data-action="format">${icon('tune', 13)}Format</button>
              <button class="mini-action" data-action="clear-code">${icon('trash', 13)}Clear</button>
              <button class="mini-action" data-action="copy-code">${icon('copy', 13)}Copy</button>
              <button class="mini-action" data-action="download-code">${icon('download', 13)}Download</button>
              <button class="dock-expand" data-action="toggle-code" title="Expand code editor">${icon('focus', 14)}</button>
            </div>
          </header>
          <div class="code-dock-body">
            <div class="code-editor-column">
              <div id="code-message" class="code-message hidden"></div>
              <div class="editor-wrap" id="editor-wrap">
                <div class="line-gutter" id="line-gutter"></div>
                <div class="editor-surface"><pre class="code-highlight" id="code-highlight" aria-hidden="true"></pre><textarea id="scene-code" spellcheck="false" autocapitalize="off" autocomplete="off" autocorrect="off" aria-label="AI Scene Code"></textarea></div>
              </div>
            </div>
            <aside class="code-output-column">
              <div class="output-card status-output"><div class="output-card-title"><strong>Run status</strong><span class="output-label">LIVE</span></div><div class="run-success"><span class="success-icon">${icon('check', 13)}</span><div><strong id="run-status-title">Scene rendered</strong><span id="run-status-detail">Ready for edits</span></div></div><div class="output-stats"><span>Objects <b id="object-count">0</b></span><span>Lights <b id="light-count">0</b></span><span>Materials <b id="material-count">0</b></span></div></div>
              <div class="output-card json-card"><div class="output-card-title"><strong>Scene JSON</strong><button class="json-view-button" data-action="view-json">View JSON ${icon('chevron', 11)}</button></div><pre id="scene-json-preview">{}</pre></div>
              <div class="sync-indicator"><span class="sync-dot" id="sync-dot"></span><span id="sync-label">Starting live sync…</span></div>
            </aside>
          </div>
        </section>
      </main>
      <aside class="inspector-panel panel-shell" id="inspector-panel">
        <nav class="inspector-tabs"><button class="inspector-tab active" data-inspector-tab="inspector">Inspector</button><button class="inspector-tab" data-inspector-tab="materials">Materials</button><button class="inspector-tab" data-inspector-tab="environment">Environment</button></nav>
        <div class="inspector-content" id="inspector-content"></div>
      </aside>
    </div>
    <footer class="statusbar"><div class="footer-brand"><span class="footer-mark">A</span><strong>AI 3D STUDIO</strong><span class="footer-divider"></span><span>Build <b>0.1.0</b></span></div><div class="footer-center"><span class="footer-key">W</span> Move <span class="footer-sep">·</span><span class="footer-key">E</span> Rotate <span class="footer-sep">·</span><span class="footer-key">R</span> Scale</div><div class="footer-right"><span class="green-dot"></span><span id="footer-sync">Local project</span><span class="footer-divider"></span><span>Mobile ready</span></div></footer>
    <input type="file" id="project-file" accept=".json,.a3d,.js,.txt" hidden>
    <div id="app-modal-root"></div>
    <div id="toast-region" class="toast-region" aria-live="polite"></div>
    <div id="mobile-backdrop" class="mobile-backdrop hidden"></div>
  </div>`;
}

function matRef(name) { return name; }
function makeMatProps(color, roughness = .7, metalness = 0, more = {}) { return { color, roughness, metalness, ...more }; }
function getMaterialSpec(material) {
  if (typeof material === 'string') return sceneData.materials.find((item) => item.name === material) || { name: material, color: '#c8d2dc', roughness: .7, metalness: 0 };
  return material || { color: '#c8d2dc', roughness: .7, metalness: 0 };
}
function getTreeMaterialTarget(node) {
  if (node?.type === 'group') return null;
  if (typeof node?.material === 'string') return sceneData.materials.find((item) => item.name === node.material) || null;
  return node?.material || null;
}

app.innerHTML = shellMarkup();
const viewportElement = document.querySelector('#viewport');
const codeArea = document.querySelector('#scene-code');
const gutter = document.querySelector('#line-gutter');
const highlight = document.querySelector('#code-highlight');

function makeGroupNode(name, position = [0, 0, 0]) { return createNode('group', { name, position }); }
function attachChild(parent, type, data) { const child = createNode(type, data); parent.children.push(child); return child; }

function initThree() {
  scene3d = new THREE.Scene();
  scene3d.background = new THREE.Color(sceneData.environment.background);
  scene3d.fog = new THREE.Fog(sceneData.environment.fog.color, sceneData.environment.fog.near, sceneData.environment.fog.far);
  camera3d = new THREE.PerspectiveCamera(sceneData.camera.fov, 1, 0.1, 500);
  camera3d.position.fromArray(sceneData.camera.position);
  renderer = new THREE.WebGLRenderer({ antialias: true, alpha: false, powerPreference: 'high-performance' });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.65));
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = sceneData.environment.intensity || 1;
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.setClearColor(sceneData.environment.background, 1);
  renderer.domElement.className = 'scene-canvas';
  viewportElement.appendChild(renderer.domElement);
  orbitControls = new OrbitControls(camera3d, renderer.domElement);
  orbitControls.enableDamping = true;
  orbitControls.dampingFactor = 0.065;
  orbitControls.target.fromArray(sceneData.camera.target);
  orbitControls.minDistance = 4;
  orbitControls.maxDistance = 140;
  orbitControls.maxPolarAngle = Math.PI * 0.492;
  orbitControls.screenSpacePanning = true;
  worldRoot = new THREE.Group();
  worldRoot.name = 'Scene objects';
  scene3d.add(worldRoot);
  const ambient = new THREE.HemisphereLight(0xe8f4ff, 0x544536, 0.48);
  ambient.name = 'Studio ambient';
  scene3d.add(ambient);
  transformControls = new TransformControls(camera3d, renderer.domElement);
  transformControls.setMode(currentToolMode);
  transformControls.setSize(0.84);
  transformControls.addEventListener('dragging-changed', (event) => { orbitControls.enabled = !event.value; });
  transformControls.addEventListener('mouseDown', () => { transformStartSnapshot = cloneValue(sceneData); });
  transformControls.addEventListener('objectChange', handleGizmoChange);
  transformControls.addEventListener('mouseUp', handleGizmoMouseUp);
  transformHelper = typeof transformControls.getHelper === 'function' ? transformControls.getHelper() : transformControls;
  scene3d.add(transformHelper);
  const resize = () => {
    const rect = viewportElement.getBoundingClientRect();
    if (!rect.width || !rect.height) return;
    camera3d.aspect = rect.width / rect.height;
    camera3d.updateProjectionMatrix();
    renderer.setSize(rect.width, rect.height, false);
  };
  new ResizeObserver(resize).observe(viewportElement);
  window.addEventListener('resize', resize);
  resize();
  renderer.domElement.addEventListener('pointerdown', (event) => { pointerDown = { x: event.clientX, y: event.clientY, button: event.button }; });
  renderer.domElement.addEventListener('pointerup', onViewportPointerUp);
  renderer.domElement.addEventListener('dblclick', () => frameSelected(true));
  renderScene3D({ resetCamera: true });
  animate();
}

function resolveMaterial(input) {
  let props = getMaterialSpec(input);
  if (typeof input === 'string') props = sceneData.materials.find((item) => item.name === input) || props;
  const key = JSON.stringify(props);
  if (materialCache.has(key)) return materialCache.get(key);
  const opts = {
    color: props.color || '#c8d2dc',
    metalness: Number(props.metalness ?? 0),
    roughness: Number(props.roughness ?? 0.68),
    opacity: Number(props.opacity ?? 1),
    transparent: Boolean(props.transparent) || Number(props.opacity ?? 1) < 1,
    emissive: props.emissive || '#000000',
    emissiveIntensity: Number(props.emissiveIntensity ?? 0),
    wireframe: Boolean(props.wireframe),
    flatShading: Boolean(props.flatShading),
    side: props.transparent ? THREE.DoubleSide : THREE.FrontSide
  };
  if (props.clearcoat != null || props.transmission != null) {
    opts.clearcoat = Number(props.clearcoat || 0);
    opts.clearcoatRoughness = Number(props.clearcoatRoughness ?? .2);
    opts.transmission = Number(props.transmission || 0);
    opts.ior = Number(props.ior || 1.5);
    opts.thickness = Number(props.thickness || 0.1);
  }
  const material = new THREE.MeshPhysicalMaterial(opts);
  material.name = props.name || 'Scene material';
  materialCache.set(key, material);
  return material;
}

function makeGeometry(node) {
  switch (node.type) {
    case 'box': return new THREE.BoxGeometry(...(node.size || [1, 1, 1]));
    case 'sphere': return new THREE.SphereGeometry(node.radius || .5, node.widthSegments || 24, node.heightSegments || 16);
    case 'cylinder': return new THREE.CylinderGeometry(node.radiusTop ?? .5, node.radiusBottom ?? .5, node.height || 1, node.radialSegments || 20);
    case 'cone': return new THREE.ConeGeometry(node.radius || .5, node.height || 1, node.radialSegments || 20);
    case 'torus': return new THREE.TorusGeometry(node.radius || .7, node.tube || .18, node.radialSegments || 12, node.tubularSegments || 40);
    case 'capsule': return new THREE.CapsuleGeometry(node.radius || .35, node.length || .7, node.capSegments || 6, node.radialSegments || 16);
    case 'plane': { const geo = new THREE.PlaneGeometry(node.size?.[0] || 1, node.size?.[1] || 1, 1, 1); geo.rotateX(-Math.PI / 2); return geo; }
    case 'circle': { const geo = new THREE.CircleGeometry(node.radius || .5, node.segments || 32); geo.rotateX(-Math.PI / 2); return geo; }
    case 'ring': { const geo = new THREE.RingGeometry(node.innerRadius || .25, node.outerRadius || .5, node.segments || 32); geo.rotateX(-Math.PI / 2); return geo; }
    default: return new THREE.BoxGeometry(1, 1, 1);
  }
}

function buildNode(node, parent) {
  let object;
  if (node.type === 'group') object = new THREE.Group();
  else if (LIGHT_TYPES.includes(node.type)) {
    if (node.type === 'directionalLight') object = new THREE.DirectionalLight(node.color || '#fff', node.intensity ?? 1);
    else if (node.type === 'pointLight') object = new THREE.PointLight(node.color || '#fff', node.intensity ?? 20, node.distance ?? 0, node.decay ?? 2);
    else if (node.type === 'spotLight') object = new THREE.SpotLight(node.color || '#fff', node.intensity ?? 80, node.distance ?? 0, node.angle ?? .4, node.penumbra ?? .2, node.decay ?? 2);
    else object = new THREE.HemisphereLight(node.color || node.skyColor || '#dbeafe', node.groundColor || '#6b5842', node.intensity ?? 1);
    if (object.isDirectionalLight || object.isSpotLight) {
      object.castShadow = node.castShadow !== false;
      object.shadow.mapSize.set(1024, 1024);
      object.shadow.bias = -0.0002;
      object.shadow.normalBias = 0.025;
      object.shadow.camera.near = 0.5;
      object.shadow.camera.far = 90;
      object.shadow.camera.left = -24; object.shadow.camera.right = 24;
      object.shadow.camera.top = 24; object.shadow.camera.bottom = -24;
      object.target.position.fromArray(node.target || [0, 0, 0]);
      parent.add(object.target);
    }
  } else {
    const geometry = makeGeometry(node);
    object = new THREE.Mesh(geometry, resolveMaterial(node.material));
    object.castShadow = node.castShadow !== false;
    object.receiveShadow = node.receiveShadow !== false;
    object.frustumCulled = true;
  }
  object.name = node.name || node.type;
  object.visible = node.visible !== false;
  object.position.fromArray(node.position || [0, 0, 0]);
  object.rotation.set(...(node.rotation || [0, 0, 0]));
  object.scale.fromArray(node.scale || [1, 1, 1]);
  object.userData.nodeId = node.id;
  object.userData.nodeType = node.type;
  objectMap.set(node.id, object);
  parent.add(object);
  if (node.children?.length) for (const child of node.children) buildNode(child, object);
  if (node.type === 'directionalLight' || node.type === 'spotLight') {
    const helper = new THREE.Mesh(new THREE.SphereGeometry(0.11, 8, 8), new THREE.MeshBasicMaterial({ color: node.color || '#ffffff' }));
    helper.name = `${node.name} marker`;
    helper.position.copy(object.position);
    helper.userData.nodeId = node.id;
    helper.userData.lightMarker = true;
    objectMap.set(`${node.id}__marker`, helper);
    parent.add(helper);
  }
  return object;
}

function disposeTree(root) {
  root.traverse((object) => {
    if (object.geometry) object.geometry.dispose();
    if (object.material) {
      const materials = Array.isArray(object.material) ? object.material : [object.material];
      materials.forEach((material) => { if (material && material !== object.material) return; });
    }
  });
}

function renderScene3D({ resetCamera = false } = {}) {
  if (!scene3d || !worldRoot) return;
  if (transformControls?.object) transformControls.detach();
  scene3d.remove(worldRoot);
  if (worldRoot) worldRoot.traverse((obj) => { if (obj.geometry) obj.geometry.dispose(); });
  if (selectionBox) { scene3d.remove(selectionBox); selectionBox.geometry?.dispose(); selectionBox = null; }
  if (gridHelper) { scene3d.remove(gridHelper); gridHelper.geometry?.dispose(); gridHelper.material?.dispose(); gridHelper = null; }
  if (axesHelper) { scene3d.remove(axesHelper); axesHelper.geometry?.dispose(); axesHelper.material?.dispose(); axesHelper = null; }
  for (const material of materialCache.values()) material.dispose();
  materialCache.clear();
  objectMap = new Map();
  worldRoot = new THREE.Group();
  worldRoot.name = 'Scene objects';
  scene3d.add(worldRoot);
  scene3d.background = new THREE.Color(sceneData.environment.background || '#b8c9d4');
  const fog = sceneData.environment.fog;
  scene3d.fog = fog && Number(fog.far) > Number(fog.near) ? new THREE.Fog(fog.color || sceneData.environment.background, fog.near, fog.far) : null;
  renderer.toneMappingExposure = Number(sceneData.environment.intensity ?? 1);
  for (const node of sceneData.objects || []) buildNode(node, worldRoot);
  if (sceneData.environment.grid) {
    gridHelper = new THREE.GridHelper(100, 80, 0x5e7990, 0x33485c);
    gridHelper.position.y = 0.018;
    gridHelper.material.transparent = true;
    gridHelper.material.opacity = 0.28;
    scene3d.add(gridHelper);
  }
  if (sceneData.environment.ground && !flattenObjects(sceneData).some((item) => ['Meadow ground', 'Ground'].includes(item.name))) {
    const ground = new THREE.Mesh(new THREE.PlaneGeometry(200, 200), resolveMaterial({ color: '#747b74', roughness: 1 }));
    ground.rotation.x = -Math.PI / 2; ground.position.y = -0.08; ground.receiveShadow = true; ground.name = 'Studio ground';
    worldRoot.add(ground);
  }
  if (resetCamera) {
    camera3d.fov = sceneData.camera?.fov || 42;
    camera3d.position.fromArray(sceneData.camera?.position || [16, 12, 19]);
    camera3d.updateProjectionMatrix();
    orbitControls.target.fromArray(sceneData.camera?.target || [0, 2, 0]);
    orbitControls.update();
  }
  if (selectedId && objectMap.has(selectedId)) {
    const selected = objectMap.get(selectedId);
    if (selected && !selected.userData.lightMarker) {
      transformControls.attach(selected);
      transformControls.setMode(currentToolMode);
      selectionBox = new THREE.BoxHelper(selected, new THREE.Color('#60a5fa'));
      selectionBox.material.depthTest = false;
      selectionBox.material.transparent = true;
      selectionBox.material.opacity = 0.9;
      selectionBox.renderOrder = 5;
      scene3d.add(selectionBox);
    }
  }
  const empty = document.querySelector('#viewport-empty');
  if (empty) empty.classList.toggle('hidden', countObjects(sceneData) > 0);
  updateSceneStats();
}

function onViewportPointerUp(event) {
  if (!pointerDown || pointerDown.button !== 0) return;
  const dx = event.clientX - pointerDown.x, dy = event.clientY - pointerDown.y;
  pointerDown = null;
  if (Math.hypot(dx, dy) > 5 || transformControls?.dragging) return;
  const rect = renderer.domElement.getBoundingClientRect();
  const mouse = new THREE.Vector2(((event.clientX - rect.left) / rect.width) * 2 - 1, -((event.clientY - rect.top) / rect.height) * 2 + 1);
  raycaster.setFromCamera(mouse, camera3d);
  const meshes = [];
  worldRoot.traverse((object) => { if (object.isMesh && !object.userData.lightMarker && object.visible) meshes.push(object); });
  const hits = raycaster.intersectObjects(meshes, false);
  if (hits.length) selectObject(hits[0].object.userData.nodeId);
  else selectObject(null);
}

function handleGizmoChange() {
  if (!selectedId) return;
  const object = objectMap.get(selectedId);
  const node = findNode(sceneData, selectedId);
  if (!object || !node) return;
  node.position = object.position.toArray();
  node.rotation = [object.rotation.x, object.rotation.y, object.rotation.z];
  node.scale = object.scale.toArray();
  transformControls.updateMatrixWorld();
  selectionBox?.update();
  renderInspector();
  updateSceneStats();
}
function handleGizmoMouseUp() {
  if (!transformStartSnapshot) return;
  const previous = transformStartSnapshot;
  transformStartSnapshot = null;
  if (JSON.stringify(previous) !== JSON.stringify(sceneData)) {
    pushHistory(previous);
    codeArea.value = sceneToCode(sceneData);
    updateEditorDecorations();
    persistLocal();
    syncScene('gizmo', true);
    updateSceneStats();
  }
}

function animate() {
  requestAnimationFrame(animate);
  const now = performance.now();
  frameCount++;
  if (now - lastFrameTime > 1000) { fps = Math.round(frameCount * 1000 / (now - lastFrameTime)); frameCount = 0; lastFrameTime = now; const label = document.querySelector('#fps-label'); if (label) label.textContent = `${fps} FPS`; }
  if (orbitControls) orbitControls.update();
  if (selectionBox) selectionBox.update();
  if (renderer && scene3d && camera3d) renderer.render(scene3d, camera3d);
}

function pushHistory(snapshot) {
  undoStack.push(snapshot || cloneValue(sceneData));
  if (undoStack.length > historyLimit) undoStack.shift();
  redoStack = [];
  updateUndoButtons();
}
function commitScene(nextScene, { label = 'Scene updated', resetCamera = false, regenerateCode = true, sync = true, previousSnapshot = null } = {}) {
  const previous = previousSnapshot || cloneValue(sceneData);
  if (JSON.stringify(previous) !== JSON.stringify(nextScene)) pushHistory(previous);
  sceneData = cloneValue(nextScene);
  lastCommitLabel = label;
  if (regenerateCode && codeArea) { codeArea.value = sceneToCode(sceneData); codeDirty = false; updateEditorDecorations(); }
  renderScene3D({ resetCamera });
  renderSidebar();
  renderInspector();
  persistLocal();
  if (sync) syncScene('browser', true);
  updateSceneStats();
  setRunStatus(label, 'Scene data and viewport are in sync', 'success');
}
function undo() {
  if (!undoStack.length) return toast('Nothing to undo', 'info');
  redoStack.push(cloneValue(sceneData));
  sceneData = undoStack.pop();
  codeArea.value = sceneToCode(sceneData); codeDirty = false; updateEditorDecorations();
  renderScene3D(); renderSidebar(); renderInspector(); persistLocal(); syncScene('undo', true); updateUndoButtons(); updateSceneStats();
  setRunStatus('Undo complete', 'Restored the previous scene state', 'success');
}
function redo() {
  if (!redoStack.length) return toast('Nothing to redo', 'info');
  undoStack.push(cloneValue(sceneData));
  sceneData = redoStack.pop();
  codeArea.value = sceneToCode(sceneData); codeDirty = false; updateEditorDecorations();
  renderScene3D(); renderSidebar(); renderInspector(); persistLocal(); syncScene('redo', true); updateUndoButtons(); updateSceneStats();
  setRunStatus('Redo complete', 'Reapplied the scene change', 'success');
}
function updateUndoButtons() {
  document.querySelector('[data-action="undo"]')?.toggleAttribute('disabled', !undoStack.length);
  document.querySelector('[data-action="redo"]')?.toggleAttribute('disabled', !redoStack.length);
}
function selectObject(id) {
  selectedId = id || null;
  if (selectedId && !findNode(sceneData, selectedId)) selectedId = null;
  renderScene3D(); renderSidebar(); renderInspector();
  const count = document.querySelector('#selection-count');
  if (count) count.textContent = selectedId ? '1 selected' : `${countObjects(sceneData)} objects`;
  if (selectedId) fetch(`/api/scenes/${encodeURIComponent(sessionId)}/selection`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ objectId: selectedId }) }).catch(() => {});
  if (selectedId && window.innerWidth <= 820) openMobilePanel('inspector');
}

function updateSceneStats() {
  const objects = countObjects(sceneData);
  let lights = 0;
  walkNodes(sceneData.objects, (node) => { if (LIGHT_TYPES.includes(node.type)) lights++; });
  const setText = (selector, text) => { const element = document.querySelector(selector); if (element) element.textContent = text; };
  setText('#object-count', String(objects));
  setText('#light-count', String(lights));
  setText('#material-count', String(sceneData.materials?.length || 0));
  setText('#selection-count', selectedId ? '1 selected' : `${objects} objects`);
  const preview = document.querySelector('#scene-json-preview');
  if (preview) {
    const compact = { version: sceneData.version, scene: sceneData.scene, objects: `Array(${objects})`, materials: `Array(${sceneData.materials?.length || 0})`, lights, camera: sceneData.camera };
    preview.textContent = JSON.stringify(compact, null, 2);
  }
  const empty = document.querySelector('#viewport-empty');
  if (empty) empty.classList.toggle('hidden', objects > 0);
}
function setRunStatus(title, detail, state = 'success') {
  const titleEl = document.querySelector('#run-status-title'); const detailEl = document.querySelector('#run-status-detail');
  if (titleEl) titleEl.textContent = title;
  if (detailEl) detailEl.textContent = detail;
  const card = document.querySelector('.run-success');
  if (card) { card.classList.toggle('has-error', state === 'error'); card.classList.toggle('is-running', state === 'running'); }
}

function updateEditorDecorations() {
  if (!codeArea || !gutter || !highlight) return;
  const value = codeArea.value || '';
  const count = Math.max(1, value.split('\n').length);
  gutter.innerHTML = Array.from({ length: count }, (_, i) => `<span>${i + 1}</span>`).join('');
  highlight.innerHTML = highlightCode(value);
  highlight.scrollTop = codeArea.scrollTop; highlight.scrollLeft = codeArea.scrollLeft;
  gutter.scrollTop = codeArea.scrollTop;
  const editorTitle = document.querySelector('.editor-title small');
  if (editorTitle) editorTitle.textContent = codeDirty ? 'Unsaved edits · Run to apply' : 'Safe, structured Scene API';
}
function escapeCode(code) { return escapeHtml(code).replace(/\t/g, '  '); }
function highlightCode(source) {
  const escaped = escapeCode(source);
  return escaped.split('\n').map((line) => line
    .replace(/(&quot;.*?&quot;|&#39;.*?&#39;|&quot;[^\n]*?&quot;)/g, '<span class="syntax-string">$1</span>')
    .replace(/\b(createBox|createSphere|createCylinder|createCone|createTorus|createCapsule|createPlane|createCircle|createRing|group|environment|camera|directionalLight|pointLight|spotLight|hemisphereLight|createMaterial|repeat|grid|scatter|setPosition|setRotation|setScale|setMaterial|clearScene|deleteObject|duplicate)\b/g, '<span class="syntax-function">$1</span>')
    .replace(/\b(name|size|position|rotation|scale|material|color|metalness|roughness|opacity|transparent|emissive|intensity|children|radius|height|fog|background|near|far|seed|count)\b(?=\s*:)/g, '<span class="syntax-key">$1</span>')
    .replace(/\b(-?\d+(?:\.\d+)?)\b/g, '<span class="syntax-number">$1</span>')
  ).join('\n') + '\n';
}
function codeMessage(message, type = 'error') {
  const target = document.querySelector('#code-message');
  if (!target) return;
  target.className = `code-message ${type}`;
  target.innerHTML = `${icon(type === 'error' ? 'alert' : 'checkCircle', 14)}<span>${escapeHtml(message)}</span><button data-action="dismiss-code-message">${icon('close', 13)}</button>`;
  target.classList.remove('hidden');
}
function hideCodeMessage() { document.querySelector('#code-message')?.classList.add('hidden'); }

function runCode() {
  hideCodeMessage();
  const code = codeArea.value.trim();
  if (!code) { codeMessage('Add some Scene API commands before running.'); return; }
  setRunStatus('Validating scene code…', 'Checking supported commands and values', 'running');
  try {
    const commands = parseSceneCode(code);
    let next = createScene(sceneData.scene?.name || 'AI Scene');
    for (const command of commands) {
      try { next = applySceneCommands(next, [command]); }
      catch (error) { throw new Error(`Line ${command.line}: ${error.message}`); }
    }
    selectedId = null;
    commitScene(next, { label: 'Scene rendered successfully', resetCamera: Boolean(next.camera), regenerateCode: false });
    codeDirty = false; updateEditorDecorations(); hideCodeMessage();
    setRunStatus('Scene rendered successfully', `${countObjects(sceneData)} objects · ${commands.length} commands`, 'success');
    toast(`Rendered ${countObjects(sceneData)} objects`, 'success');
  } catch (error) {
    const message = error.message || 'Scene code could not be parsed.';
    codeMessage(message, 'error');
    setRunStatus('Scene code needs attention', message, 'error');
    toast('Could not run scene code', 'error');
  }
}

function renderSidebar() {
  document.querySelectorAll('.side-tab').forEach((tab) => tab.classList.toggle('active', tab.dataset.section === currentSection));
  const root = document.querySelector('#left-content');
  if (!root) return;
  if (currentSection === 'scene') root.innerHTML = renderSceneSidebar();
  else if (currentSection === 'guide') root.innerHTML = renderGuideSidebar();
  else if (currentSection === 'mcp') root.innerHTML = renderMcpSidebar();
  else root.innerHTML = renderDocsSidebar();
}
function typeIcon(type) {
  if (type === 'group') return icon('folder', 14);
  if (type === 'box') return icon('cubeSmall', 14);
  if (type === 'sphere' || type === 'circle') return icon('sphere', 14);
  if (type.includes('Light')) return icon('sun', 14);
  if (type === 'plane') return icon('grid', 14);
  return icon('box', 14);
}
function visibleForSearch(node, term) {
  return node.name.toLowerCase().includes(term) || (node.children || []).some((child) => visibleForSearch(child, term));
}
function renderTreeNode(node, depth = 0) {
  const hasChildren = Boolean(node.children?.length);
  const expanded = searchTerm ? true : expandedIds.has(node.id);
  const isSelected = node.id === selectedId;
  const typeClass = LIGHT_TYPES.includes(node.type) ? 'light' : node.type === 'group' ? 'group' : 'object';
  let html = `<div class="tree-row ${isSelected ? 'selected' : ''} ${node.visible === false ? 'muted' : ''}" style="--depth:${depth}" data-node-row="${escapeHtml(node.id)}">
      <button class="tree-expander ${hasChildren ? '' : 'empty'}" data-action="expand-node" data-id="${escapeHtml(node.id)}" aria-label="${expanded ? 'Collapse' : 'Expand'}">${hasChildren ? icon(expanded ? 'down' : 'chevron', 12) : ''}</button>
      <span class="tree-type ${typeClass}">${typeIcon(node.type)}</span>
      <button class="tree-label" data-action="select-node" data-id="${escapeHtml(node.id)}" title="${escapeHtml(node.name)}">${escapeHtml(node.name)}</button>
      <button class="tree-visibility ${node.visible === false ? 'off' : ''}" data-action="toggle-visible" data-id="${escapeHtml(node.id)}" title="Toggle visibility">${icon(node.visible === false ? 'eyeOff' : 'eye', 13)}</button>
    </div>`;
  if (hasChildren && expanded) {
    for (const child of node.children) {
      if (!searchTerm || visibleForSearch(child, searchTerm)) html += renderTreeNode(child, depth + 1);
    }
  }
  return html;
}
function renderSceneSidebar() {
  const term = searchTerm.toLowerCase().trim();
  const visibleNodes = sceneData.objects.filter((node) => !term || visibleForSearch(node, term));
  const rows = visibleNodes.map((node) => renderTreeNode(node, 0)).join('');
  return `<div class="sidebar-scroll scene-sidebar">
    <div class="sidebar-section-head"><div><span class="section-eyebrow">WORKSPACE</span><h2>Scene hierarchy</h2></div><button class="quiet-icon-button" data-action="add-menu" title="Add object">${icon('plus', 16)}</button></div>
    <div class="search-box">${icon('search', 14)}<input id="scene-search" placeholder="Search objects…" value="${escapeHtml(searchTerm)}"><span class="search-shortcut">⌘ K</span></div>
    <div class="tree-root-label"><span>${icon('scene', 14)}${escapeHtml(sceneData.scene?.name || 'Scene')}</span><button data-action="select-scene" title="Select scene">${icon('eye', 13)}</button></div>
    <div class="hierarchy-list">${rows || `<div class="empty-tree"><div class="empty-glyph">${icon('cube', 20)}</div><span>${term ? 'No matching objects' : 'Your scene is empty'}</span><small>${term ? 'Try a different search' : 'Add a primitive or run AI code'}</small></div>`}</div>
    <div class="scene-side-footer"><div class="guide-teaser-head"><span class="guide-mini-icon">${icon('sparkle', 14)}</span><div><strong>AI 3D Guide</strong><small>Prompt → scene, safely</small></div><button data-section="guide" aria-label="Open AI guide">${icon('chevron', 13)}</button></div><p>Generate structured 3D scenes with any AI assistant using our ready-to-copy master prompt.</p><button class="copy-prompt-button" data-action="copy-prompt">${icon('copy', 13)}Copy Master Prompt</button><button class="sidebar-link" data-section="docs">${icon('docs', 13)}Scene API reference<span>${icon('chevron', 12)}</span></button><button class="sidebar-link" data-section="mcp">${icon('mcp', 13)}MCP setup<span>${icon('chevron', 12)}</span></button></div>
    <div class="sidebar-sync-card"><span class="mcp-ring">${icon('mcp', 17)}</span><div><strong>${wsStatus === 'online' ? 'Live scene sync' : 'Local scene session'}</strong><small>${wsStatus === 'online' ? 'Browser bridge connected' : 'Saved in this browser'}</small></div><span class="status-dot ${wsStatus === 'online' ? 'is-online' : ''}"></span></div>
  </div>`;
}
function renderGuideSidebar() {
  return `<div class="sidebar-scroll info-sidebar">
    <div class="sidebar-section-head"><div><span class="section-eyebrow">AI WORKFLOW</span><h2>AI 3D Guide</h2></div><span class="count-pill">01 / 02</span></div>
    <div class="guide-intro-card"><div class="guide-orbit">${icon('sparkle', 22)}</div><span class="eyebrow-blue">NO API KEY REQUIRED</span><h3>From a sentence<br>to a scene.</h3><p>Use any AI assistant to describe a model, then run its validated Scene API code right here.</p></div>
    <div class="workflow-list"><div class="workflow-step"><span>01</span><div><strong>Copy the master prompt</strong><small>Teaches your AI the scene format</small></div></div><div class="workflow-step"><span>02</span><div><strong>Describe what to build</strong><small>Ask for a chair, city, spaceship…</small></div></div><div class="workflow-step"><span>03</span><div><strong>Paste & run the code</strong><small>Safe parser, instant 3D render</small></div></div></div>
    <div class="card-subhead"><strong>Master prompt</strong><button class="text-action" data-action="copy-prompt">${icon('copy', 12)}Copy</button></div>
    <div class="prompt-preview">${escapeHtml(MASTER_PROMPT.slice(0, 460))}<span class="prompt-fade">…</span></div>
    <button class="copy-prompt-button full" data-action="copy-prompt">${icon('copy', 13)}Copy full Master Prompt</button>
    <div class="prompt-note">Your code is parsed as structured data. Arbitrary JavaScript is never executed.</div>
    <div class="card-subhead"><strong>Try an example</strong><span class="count-pill">ready to run</span></div><div class="example-buttons"><button data-action="example-cube">${icon('cubeSmall', 13)}Red cube</button><button data-action="example-chair">${icon('layers', 13)}Wooden chair</button></div>
    <div class="sidebar-link-list"><button class="sidebar-link" data-section="docs">${icon('docs', 13)}Open Scene API reference${icon('chevron', 12)}</button><button class="sidebar-link" data-section="mcp">${icon('mcp', 13)}Connect via MCP${icon('chevron', 12)}</button></div>
  </div>`;
}
function renderMcpSidebar() {
  const endpoint = mcpEndpoint();
  return `<div class="sidebar-scroll info-sidebar mcp-sidebar">
    <div class="sidebar-section-head"><div><span class="section-eyebrow">DIRECT AI CONTROL</span><h2>Connect with MCP</h2></div><span class="mcp-badge ${mcpServerOnline ? 'online' : ''}"><i></i>${mcpServerOnline ? 'ONLINE' : 'LOCAL'}</span></div>
    <div class="mcp-hero"><div class="mcp-hero-icon">${icon('mcp', 24)}</div><h3>Let AI operate<br>your scene.</h3><p>Expose typed tools so a connected assistant can add objects, edit materials, and iterate in your browser.</p></div>
    <div class="connection-state-card"><div class="connection-state-line"><span class="state-icon">${icon(mcpServerOnline ? 'checkCircle' : 'cloud', 15)}</span><div><strong>${mcpServerOnline ? 'Studio bridge online' : 'Checking bridge'}</strong><small>${mcpServerOnline ? 'This editor is synced to its scene session' : 'Starting the local API…'}</small></div></div><span class="state-label">${wsStatus === 'online' ? 'SYNCED' : 'BROWSER ONLY'}</span></div>
    <label class="field-label mcp-endpoint-label">REMOTE MCP ENDPOINT <button class="quiet-icon-button tiny" data-action="copy-mcp-url" title="Copy endpoint">${icon('copy', 12)}</button></label>
    <div class="endpoint-input"><input id="mcp-endpoint" readonly value="${escapeHtml(endpoint)}"></div>
    <button class="copy-prompt-button full" data-action="copy-mcp-url">${icon('copy', 13)}Copy MCP URL</button>
    <button class="secondary-wide-button" data-action="test-mcp">${icon('checkCircle', 14)}Test connection</button>
    <div class="mcp-tool-block"><div class="card-subhead"><strong>Available tools</strong><span class="count-pill">20</span></div><div class="tool-chips"><span>add_object</span><span>set_material</span><span>set_transform</span><span>get_scene</span><span>run_scene_code</span><span>+15 more</span></div></div>
    <div class="warning-note"><span>${icon('info', 14)}</span><p>This preview endpoint is session-scoped. To connect ChatGPT over the internet, deploy this server to a stable public HTTPS domain and configure authentication.</p></div>
    <button class="sidebar-link" data-action="copy-mcp-setup">${icon('docs', 13)}Copy setup instructions${icon('chevron', 12)}</button>
  </div>`;
}
function renderDocsSidebar() {
  return `<div class="sidebar-scroll info-sidebar docs-sidebar"><div class="sidebar-section-head"><div><span class="section-eyebrow">REFERENCE</span><h2>Scene API</h2></div><span class="count-pill">${PRIMITIVE_TYPES.length} primitives</span></div><div class="docs-intro"><p>Small, typed commands make powerful 3D scenes. The editor validates every call before rendering.</p></div>${API_REFERENCE.map((item, index) => `<details class="doc-accordion" ${index === 0 ? 'open' : ''}><summary><span class="doc-number">0${index + 1}</span><span>${escapeHtml(item.title)}</span>${icon('down', 13)}</summary><p>${escapeHtml(item.description)}</p><code>${escapeHtml(item.example)}</code></details>`).join('')}<div class="security-note"><span>${icon('checkCircle', 14)}</span><div><strong>Safe by design</strong><p>Literal-only parser · No eval · Bounded geometry</p></div></div><button class="copy-prompt-button full" data-action="copy-prompt">${icon('copy', 13)}Copy AI Master Prompt</button></div>`;
}

function materialCounts() {
  const set = new Set((sceneData.materials || []).map((mat) => mat.name));
  walkNodes(sceneData.objects, (node) => { if (typeof node.material === 'string') set.add(node.material); else if (node.material?.name) set.add(node.material.name); });
  return set.size;
}
function makeInput(label, value, opts = {}) {
  const { unit = '', min = '', max = '', step = '0.1', key = '', axis = '', type = 'number' } = opts;
  if (type === 'color') return `<div class="color-input-wrap"><input type="color" value="${escapeHtml(value || '#ffffff')}" data-inspector-material="${escapeHtml(key)}"><input type="text" value="${escapeHtml(value || '#ffffff')}" data-inspector-material="${escapeHtml(key)}" class="color-hex-input"></div>`;
  return `<div class="value-input-wrap"><input type="${type}" value="${escapeHtml(value)}" ${min !== '' ? `min="${min}"` : ''} ${max !== '' ? `max="${max}"` : ''} step="${step}" data-transform="${escapeHtml(key)}" data-axis="${axis}">${unit ? `<span>${unit}</span>` : ''}</div>`;
}
function renderVectorRow(title, values, key, step = '0.1') {
  const labels = ['X', 'Y', 'Z'];
  return `<div class="vector-row"><div class="vector-label">${title}</div><div class="vector-inputs">${values.map((value, axis) => `<label class="axis-input"><span>${labels[axis]}</span><input type="number" step="${step}" value="${fmt(value)}" data-transform="${key}" data-axis="${axis}" aria-label="${title} ${labels[axis]}"></label>`).join('')}</div></div>`;
}
function renderInspector() {
  document.querySelectorAll('.inspector-tab').forEach((tab) => tab.classList.toggle('active', tab.dataset.inspectorTab === inspectorTab));
  const container = document.querySelector('#inspector-content');
  if (!container) return;
  if (inspectorTab === 'materials') { container.innerHTML = renderMaterialsPanel(); return; }
  if (inspectorTab === 'environment') { container.innerHTML = renderEnvironmentPanel(); return; }
  const node = selectedId ? findNode(sceneData, selectedId) : null;
  if (!node) { container.innerHTML = renderSceneInspector(); return; }
  const material = node.type === 'group' ? null : getTreeMaterialTarget(node);
  const meshNode = node.type !== 'group' && !LIGHT_TYPES.includes(node.type);
  const geometry = renderGeometryFields(node);
  const materialSection = material ? renderMaterialEditor(node, material) : `<div class="material-summary"><div class="material-orb">${icon('layers', 18)}</div><div><strong>${node.type === 'group' ? 'Multiple materials' : 'Light source'}</strong><small>${node.type === 'group' ? 'Select a mesh to edit its finish' : 'Material controls not applicable'}</small></div></div>`;
  container.innerHTML = `<div class="inspector-object-head"><div class="object-avatar ${node.type === 'group' ? 'is-group' : ''}">${typeIcon(node.type)}</div><div class="object-title"><input class="object-name-input" value="${escapeHtml(node.name)}" data-node-name aria-label="Object name"><span>${escapeHtml(niceName(node.type))}${node.type === 'group' ? ' · Group' : ''}</span></div><div class="object-head-actions"><button class="quiet-icon-button tiny" data-action="duplicate-selected" title="Duplicate">${icon('copy', 13)}</button><button class="quiet-icon-button tiny danger" data-action="delete-selected" title="Delete">${icon('trash', 13)}</button></div></div>
    <section class="inspector-section"><button class="inspector-section-title" data-action="toggle-section" data-id="transform-section"><span>${icon('move', 14)}Transform</span>${icon('down', 12)}</button><div id="transform-section" class="section-body">${renderVectorRow('Position', node.position, 'position')}${renderVectorRow('Rotation', node.rotation, 'rotation', '0.05')}${renderVectorRow('Scale', node.scale, 'scale', '0.05')}</div></section>
    <section class="inspector-section"><button class="inspector-section-title" data-action="toggle-section" data-id="geometry-section"><span>${icon('cubeSmall', 14)}Geometry</span>${icon('down', 12)}</button><div id="geometry-section" class="section-body"><div class="geometry-type-row"><span>Type</span><strong>${escapeHtml(niceName(node.type))}</strong></div>${geometry}</div></section>
    <section class="inspector-section"><button class="inspector-section-title" data-action="toggle-section" data-id="material-section"><span>${icon('material', 14)}Material</span>${icon('down', 12)}</button><div id="material-section" class="section-body">${materialSection}</div></section>
    <section class="inspector-section"><button class="inspector-section-title" data-action="toggle-section" data-id="render-section"><span>${icon('eye', 14)}Rendering</span>${icon('down', 12)}</button><div id="render-section" class="section-body render-options">${renderToggle('Visible', 'visible', node.visible !== false)}${renderToggle('Cast shadows', 'castShadow', node.castShadow !== false, !meshNode)}${renderToggle('Receive shadows', 'receiveShadow', node.receiveShadow !== false, !meshNode)}${meshNode ? renderToggle('Wireframe', 'wireframe', Boolean(getMaterialSpec(node.material).wireframe), false, true) : ''}</div></section>`;
}
function renderSceneInspector() {
  return `<div class="inspector-object-head scene-inspector-head"><div class="object-avatar is-scene">${icon('scene', 17)}</div><div class="object-title"><strong>${escapeHtml(sceneData.scene?.name || 'Untitled Scene')}</strong><span>Scene settings</span></div><button class="quiet-icon-button tiny" data-action="rename-scene" title="Rename scene">${icon('tune', 14)}</button></div>
  <div class="scene-inspector-intro"><span class="live-dot"></span><div><strong>Scene ready</strong><small>${countObjects(sceneData)} objects · ${materialCounts()} materials</small></div></div>
  <section class="inspector-section"><div class="static-section-title">Quick create</div><div class="quick-create-grid"><button data-action="add-cube">${icon('cube', 17)}<span>Cube</span></button><button data-action="add-sphere">${icon('sphere', 17)}<span>Sphere</span></button><button data-action="add-cylinder">${icon('box', 17)}<span>Cylinder</span></button><button data-action="add-light">${icon('sun', 17)}<span>Light</span></button></div></section>
  <section class="inspector-section"><div class="static-section-title">Scene environment</div>${environmentSummary(sceneData.environment)}</section>
  <div class="inspector-hint">Select an object in the viewport or hierarchy to edit its properties.</div>`;
}
function renderGeometryFields(node) {
  if (node.type === 'group') return `<div class="geometry-note">${node.children?.length || 0} direct children<button class="text-action" data-action="focus-selected">${icon('focus', 12)}Frame</button></div>`;
  if (LIGHT_TYPES.includes(node.type)) return `<div class="inspector-property-row color-property"><span>Light color</span>${makeInput('Light color', node.color || '#ffffff', { type: 'color', key: 'color' }).replaceAll('data-inspector-material=', 'data-inspector-light=')}</div><div class="slider-property"><div><span>Intensity</span><output>${fmt(node.intensity ?? 1, 1)}</output></div><input type="range" min="0" max="100" step="0.1" value="${Number(node.intensity ?? 1)}" data-inspector-light="intensity"></div>`;
  if (node.type === 'box') return `<div class="geometry-dimensions"><span>Dimensions (m)</span><div class="dimension-inputs">${node.size.map((v, i) => `<label><span>${['X', 'Y', 'Z'][i]}</span><input type="number" min="0.001" step="0.1" value="${fmt(v)}" data-geometry="size" data-axis="${i}"></label>`).join('')}</div></div>`;
  if (node.type === 'plane') return `<div class="geometry-dimensions"><span>Size (m)</span><div class="dimension-inputs two">${node.size.map((v, i) => `<label><span>${['W', 'D'][i]}</span><input type="number" min="0.001" step="0.1" value="${fmt(v)}" data-geometry="size" data-axis="${i}"></label>`).join('')}</div></div>`;
  const values = [];
  if (['sphere', 'cone', 'circle'].includes(node.type)) values.push(['Radius', 'radius', node.radius]);
  if (node.type === 'cylinder') values.push(['Top radius', 'radiusTop', node.radiusTop], ['Bottom radius', 'radiusBottom', node.radiusBottom]);
  if (['cylinder', 'cone'].includes(node.type)) values.push(['Height', 'height', node.height]);
  if (node.type === 'torus') values.push(['Major radius', 'radius', node.radius], ['Tube radius', 'tube', node.tube]);
  if (node.type === 'capsule') values.push(['Radius', 'radius', node.radius], ['Length', 'length', node.length]);
  if (node.type === 'ring') values.push(['Inner radius', 'innerRadius', node.innerRadius], ['Outer radius', 'outerRadius', node.outerRadius]);
  return values.map(([label, key, value]) => `<div class="geometry-value-row"><span>${label}</span><input type="number" min="0.001" step="0.1" value="${fmt(value)}" data-geometry="${key}"></div>`).join('');
}
function renderMaterialEditor(node, material) {
  const name = material.name || (typeof node.material === 'string' ? node.material : 'Custom material');
  return `<div class="material-topline"><div class="material-preview-ball" style="--material-color:${escapeHtml(material.color || '#c8d2dc')};--metalness:${Number(material.metalness || 0)}">${icon('material', 17)}</div><div class="material-name-control"><span>Assigned finish</span><button data-action="select-material">${escapeHtml(name)}${icon('down', 12)}</button></div></div>
  <div class="inspector-property-row color-property"><span>Base color</span>${makeInput('Color', material.color || '#c8d2dc', { type: 'color', key: 'color' })}</div>
  ${renderSlider('Metalness', 'metalness', material.metalness ?? 0, 0, 1)}
  ${renderSlider('Roughness', 'roughness', material.roughness ?? .65, 0, 1)}
  ${renderSlider('Opacity', 'opacity', material.opacity ?? 1, 0, 1)}
  ${renderToggle('Emissive', 'emissiveEnabled', Number(material.emissiveIntensity || 0) > 0, false, true)}
  ${Number(material.emissiveIntensity || 0) > 0 ? `<div class="inspector-property-row color-property"><span>Glow color</span>${makeInput('Emissive color', material.emissive || '#ffffff', { type: 'color', key: 'emissive' })}</div>` : ''}
  ${renderToggle('Transparent', 'transparent', Boolean(material.transparent), false, true)}`;
}
function renderSlider(label, key, value, min, max) {
  return `<div class="slider-property"><div><span>${label}</span><output>${fmt(value, 2)}</output></div><input type="range" min="${min}" max="${max}" step="0.01" value="${Number(value)}" data-inspector-material="${key}"></div>`;
}
function renderToggle(label, key, checked, disabled = false, isMaterial = false) {
  return `<div class="toggle-property"><span>${label}</span><button class="toggle-switch ${checked ? 'on' : ''}" data-toggle-key="${key}" data-material-toggle="${isMaterial ? 'true' : 'false'}" aria-pressed="${checked}" ${disabled ? 'disabled' : ''}><i></i></button></div>`;
}
function renderMaterialsPanel() {
  const usedNames = new Set();
  const materials = [...(sceneData.materials || [])];
  walkNodes(sceneData.objects, (node) => {
    if (typeof node.material === 'string' && !usedNames.has(node.material)) {
      usedNames.add(node.material);
      if (!materials.some((m) => m.name === node.material)) materials.push({ name: node.material, color: '#c8d2dc', metalness: 0, roughness: .65 });
    } else if (node.material && typeof node.material === 'object' && node.material.name && !usedNames.has(node.material.name)) { usedNames.add(node.material.name); materials.push(node.material); }
  });
  return `<div class="inspector-object-head"><div class="object-avatar is-scene">${icon('material', 17)}</div><div class="object-title"><strong>Material library</strong><span>${materials.length} finishes in this scene</span></div><button class="quiet-icon-button tiny" data-action="add-material" title="Add material">${icon('plus', 15)}</button></div>
    <div class="material-library-list">${materials.map((material, index) => `<button class="material-library-item ${selectedId && findNode(sceneData, selectedId)?.material === material.name ? 'selected' : ''}" data-action="apply-material" data-material-name="${escapeHtml(material.name || `Material ${index + 1}`)}"><span class="material-swatch" style="--material-color:${escapeHtml(material.color || '#c8d2dc')}"></span><span><strong>${escapeHtml(material.name || `Material ${index + 1}`)}</strong><small>Metal ${fmt(material.metalness || 0, 2)} · Rough ${fmt(material.roughness ?? .65, 2)}</small></span><span class="material-actions">${selectedId && findNode(sceneData, selectedId)?.material === material.name ? icon('check', 13) : icon('chevron', 13)}</span></button>`).join('') || '<div class="empty-tree">No materials yet</div>'}</div>
    <div class="material-add-card"><span>${icon('sparkle', 15)}</span><div><strong>Consistent materials</strong><small>Shared finishes update every assigned object.</small></div></div>`;
}
function environmentSummary(env) {
  return `<div class="environment-summary"><span class="environment-swatch" style="--environment-color:${escapeHtml(env.background)}"></span><div><strong>${escapeHtml(env.background)}</strong><small>Background & fog</small></div><button class="text-action" data-inspector-tab="environment">Edit ${icon('chevron', 11)}</button></div>`;
}
function renderEnvironmentPanel() {
  const env = sceneData.environment;
  return `<div class="inspector-object-head"><div class="object-avatar is-scene">${icon('sun', 17)}</div><div class="object-title"><strong>Environment</strong><span>World, ground & atmosphere</span></div></div>
    <section class="inspector-section"><div class="static-section-title">Background</div><div class="inspector-property-row color-property"><span>Sky color</span>${makeInput('Sky color', env.background || '#b8c9d4', { type: 'color', key: 'environment.background' })}</div>${renderToggle('Ground plane', 'environment.ground', env.ground !== false)}${renderToggle('Viewport grid', 'environment.grid', Boolean(env.grid))}</section>
    <section class="inspector-section"><div class="static-section-title">Atmosphere</div><div class="inspector-property-row color-property"><span>Fog color</span>${makeInput('Fog color', env.fog?.color || env.background, { type: 'color', key: 'environment.fog.color' })}</div>${renderSlider('Fog start', 'environment.fog.near', env.fog?.near ?? 50, 0, 200)}${renderSlider('Fog distance', 'environment.fog.far', env.fog?.far ?? 200, 20, 400)}</section>
    <section class="inspector-section"><div class="static-section-title">Lighting</div>${renderSlider('Exposure', 'environment.intensity', env.intensity ?? 1, .2, 2)}</section>
    <div class="environment-tip">${icon('info', 13)}Fog creates depth by softening distant objects.</div>`;
}

function loadCodeExample(kind) {
  const examples = {
    cube: `environment({background:"#b7c9d4",grid:true});\ndirectionalLight({name:"Softbox",color:"#fff1d8",intensity:2.2,position:[5,8,6],castShadow:true});\ncreateBox({name:"Red Cube",size:[2,2,2],position:[0,1,0],material:{color:"#ef4444",metalness:0.08,roughness:0.42}});`,
    chair: `environment({background:"#b7c9d4",grid:true});\ndirectionalLight({name:"Warm key",color:"#ffe6c7",intensity:2.3,position:[5,9,6],castShadow:true});\ngroup({name:"Oak Chair",position:[0,0,0],children:[\n  {type:"box",name:"Seat",size:[1.6,0.18,1.45],position:[0,1.15,0],material:{color:"#805535",roughness:0.62}},\n  {type:"box",name:"Backrest",size:[1.55,1.35,0.16],position:[0,1.88,-0.64],material:{color:"#805535",roughness:0.62}},\n  {type:"box",name:"Front left leg",size:[0.16,1.1,0.16],position:[-0.62,0.55,0.55],material:{color:"#4c3023",roughness:0.56}},\n  {type:"box",name:"Front right leg",size:[0.16,1.1,0.16],position:[0.62,0.55,0.55],material:{color:"#4c3023",roughness:0.56}},\n  {type:"box",name:"Rear left leg",size:[0.16,1.1,0.16],position:[-0.62,0.55,-0.55],material:{color:"#4c3023",roughness:0.56}},\n  {type:"box",name:"Rear right leg",size:[0.16,1.1,0.16],position:[0.62,0.55,-0.55],material:{color:"#4c3023",roughness:0.56}}\n]});`
  };
  codeArea.value = examples[kind] || examples.cube;
  codeDirty = true; updateEditorDecorations(); hideCodeMessage();
  toast('Example loaded into the code editor · press Run', 'info');
}
function copyText(text, successMessage = 'Copied to clipboard') {
  const fallback = () => {
    const area = document.createElement('textarea'); area.value = text; area.style.position = 'fixed'; area.style.opacity = '0'; document.body.appendChild(area); area.select(); document.execCommand('copy'); area.remove();
  };
  if (navigator.clipboard?.writeText) navigator.clipboard.writeText(text).then(() => toast(successMessage, 'success')).catch(() => { fallback(); toast(successMessage, 'success'); });
  else { fallback(); toast(successMessage, 'success'); }
}
function mcpEndpoint() {
  const origin = window.location.origin;
  return `${origin}/mcp?sessionId=${encodeURIComponent(sessionId)}`;
}
function mcpSetupInstructions() {
  return `AI 3D Studio MCP setup\n\n1. Deploy this project to a stable public HTTPS URL. The editor preview URL is temporary and may not be reachable from ChatGPT.\n2. Configure MCP_API_TOKEN (or add production OAuth) on the server. Keep credentials server-side.\n3. In a ChatGPT surface that supports custom MCP apps, add this remote server URL:\n${mcpEndpoint()}\n4. Authorize/enable the app, open AI 3D Studio in your browser, then ask ChatGPT to inspect or create objects.\n\nThe URL contains a private scene-session capability. Do not share it publicly. ChatGPT plan/workspace availability varies; verify the current product settings.`;
}

function toast(message, type = 'success') {
  const region = document.querySelector('#toast-region');
  if (!region) return;
  const toastEl = document.createElement('div');
  toastEl.className = `toast ${type}`;
  toastEl.innerHTML = `<span class="toast-icon">${icon(type === 'error' ? 'alert' : type === 'info' ? 'info' : 'checkCircle', 15)}</span><span>${escapeHtml(message)}</span>`;
  region.appendChild(toastEl);
  setTimeout(() => { toastEl.classList.add('out'); setTimeout(() => toastEl.remove(), 250); }, 2800);
}

function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a'); anchor.href = url; anchor.download = filename; anchor.click();
  setTimeout(() => URL.revokeObjectURL(url), 1500);
}
function safeFileName(name) { return String(name || 'scene').toLowerCase().replace(/[^a-z0-9-_]+/g, '-').replace(/^-|-$/g, '') || 'scene'; }
function exportJson() { downloadBlob(new Blob([JSON.stringify(sceneData, null, 2)], { type: 'application/json' }), `${safeFileName(sceneData.scene?.name)}.json`); toast('Scene JSON exported', 'success'); }
function exportCode() { downloadBlob(new Blob([sceneToCode(sceneData)], { type: 'text/plain' }), `${safeFileName(sceneData.scene?.name)}.a3d.js`); toast('Scene code exported', 'success'); }
async function exportGlb() {
  try {
    const exporter = new GLTFExporter();
    const data = await exporter.parseAsync(worldRoot, { binary: true, trs: false, onlyVisible: true, maxTextureSize: 2048 });
    downloadBlob(new Blob([data], { type: 'model/gltf-binary' }), `${safeFileName(sceneData.scene?.name)}.glb`);
    toast('GLB exported', 'success');
  } catch (error) { toast(`GLB export failed: ${error.message}`, 'error'); }
}

function addPrimitive(type) {
  const sizes = { box: [2, 2, 2], sphere: undefined, cylinder: undefined, cone: undefined, torus: undefined, capsule: undefined, plane: [4, 4], circle: undefined, ring: undefined };
  let props = { name: `${niceName(type)} ${String(countObjects(sceneData) + 1).padStart(2, '0')}`, position: [0, 1, 0], material: { color: '#6b9cff', metalness: .18, roughness: .48 }, castShadow: true, receiveShadow: true };
  if (sizes[type]) props.size = sizes[type];
  else if (type === 'sphere') props.radius = 1;
  else if (type === 'cylinder') Object.assign(props, { radiusTop: .75, radiusBottom: .75, height: 2 });
  else if (type === 'cone') Object.assign(props, { radius: 1, height: 2 });
  else if (type === 'torus') Object.assign(props, { radius: .9, tube: .22, rotation: [Math.PI / 2, 0, 0] });
  else if (type === 'capsule') Object.assign(props, { radius: .5, length: 1 });
  else if (type === 'circle') Object.assign(props, { radius: 1 });
  else if (type === 'ring') Object.assign(props, { innerRadius: .55, outerRadius: 1 });
  const next = cloneValue(sceneData);
  try { const node = createNode(type, props); addNode(next, node); selectedId = node.id; commitScene(next, { label: `${niceName(type)} added` }); toast(`${niceName(type)} added`, 'success'); }
  catch (error) { toast(error.message, 'error'); }
}
function addLight() {
  const next = cloneValue(sceneData);
  const light = createNode('pointLight', { name: `Point Light ${countObjects(next) + 1}`, color: '#ffe2ae', intensity: 18, distance: 24, position: [3, 5, 3] });
  addNode(next, light); selectedId = light.id; commitScene(next, { label: 'Point light added' }); toast('Point light added', 'success');
}
function addGroup() {
  const next = cloneValue(sceneData);
  const group = createNode('group', { name: `Group ${countObjects(next) + 1}`, position: [0, 0, 0] });
  addNode(next, group); selectedId = group.id; expandedIds.add(group.id); commitScene(next, { label: 'Group added' });
}
function deleteSelected() {
  if (!selectedId) return;
  const next = cloneValue(sceneData);
  const remove = (nodes) => { const index = nodes.findIndex((node) => node.id === selectedId); if (index >= 0) return nodes.splice(index, 1)[0]; for (const node of nodes) { const result = remove(node.children || []); if (result) return result; } return null; };
  const deleted = remove(next.objects);
  if (!deleted) return;
  selectedId = null; commitScene(next, { label: `${deleted.name} deleted` });
}
function duplicateSelected() {
  if (!selectedId) return;
  const next = cloneValue(sceneData); const source = findNode(next, selectedId); if (!source) return;
  const copy = cloneValue(source);
  const regenerate = (node) => { node.id = createId(node.type === 'group' ? 'group' : 'obj'); node.name += ' Copy'; for (const child of node.children || []) regenerate(child); };
  regenerate(copy); copy.position[0] += 1.5; next.objects.push(copy); selectedId = copy.id; commitScene(next, { label: `${source.name} duplicated` });
}
function focusSelected() { frameSelected(true); }
function frameSelected(animateCamera = true) {
  const object = selectedId ? objectMap.get(selectedId) : null;
  if (!object || object.userData.lightMarker) { frameAll(); return; }
  const box = new THREE.Box3().setFromObject(object); if (box.isEmpty()) return;
  const sphere = box.getBoundingSphere(new THREE.Sphere()); const center = sphere.center;
  const distance = Math.max(sphere.radius * 2.7, 4.5);
  const direction = camera3d.position.clone().sub(orbitControls.target).normalize();
  const targetPosition = center.clone().add(direction.multiplyScalar(distance));
  orbitControls.target.copy(center);
  camera3d.position.copy(targetPosition);
  orbitControls.update();
  toast(`Framed ${findNode(sceneData, selectedId)?.name || 'selection'}`, 'info');
}
function frameAll() {
  const box = new THREE.Box3().setFromObject(worldRoot);
  if (box.isEmpty()) { camera3d.position.set(12, 10, 14); orbitControls.target.set(0, 0, 0); return; }
  const sphere = box.getBoundingSphere(new THREE.Sphere()); const distance = Math.max(sphere.radius * 1.85, 8);
  orbitControls.target.copy(sphere.center); camera3d.position.copy(sphere.center.clone().add(new THREE.Vector3(1, .72, 1.1).normalize().multiplyScalar(distance))); orbitControls.update();
}
function setToolMode(mode) {
  currentToolMode = mode;
  transformControls.setMode(mode);
  document.querySelectorAll('.view-tool[data-tool]').forEach((button) => button.classList.toggle('active', button.dataset.tool === mode));
}
function cycleCameraPreset() {
  const presets = [
    { name: 'Perspective', direction: [1, .66, 1.08], up: [0, 1, 0] },
    { name: 'Top', direction: [.001, 1, .001], up: [0, 0, -1] },
    { name: 'Front', direction: [0, .14, 1], up: [0, 1, 0] },
    { name: 'Right', direction: [1, .14, 0], up: [0, 1, 0] }
  ];
  cameraPresetIndex = (cameraPresetIndex + 1) % presets.length;
  const preset = presets[cameraPresetIndex];
  const target = selectedId && objectMap.has(selectedId) ? new THREE.Box3().setFromObject(objectMap.get(selectedId)).getCenter(new THREE.Vector3()) : orbitControls.target.clone();
  const distance = Math.max(camera3d.position.distanceTo(orbitControls.target), 15);
  camera3d.up.set(...preset.up);
  camera3d.position.copy(target.clone().add(new THREE.Vector3(...preset.direction).normalize().multiplyScalar(distance)));
  orbitControls.target.copy(target);
  camera3d.lookAt(target);
  orbitControls.update();
  const label = document.querySelector('.viewport-select span');
  if (label) label.textContent = preset.name;
}
function toggleGrid() {
  const next = cloneValue(sceneData); next.environment.grid = !next.environment.grid; commitScene(next, { label: next.environment.grid ? 'Grid enabled' : 'Grid disabled', regenerateCode: true });
}
function renameScene() {
  openModal('Rename scene', `<label class="modal-field"><span>SCENE NAME</span><input id="modal-name" maxlength="80" value="${escapeHtml(sceneData.scene?.name || 'Untitled Scene')}"></label>`, `<button class="modal-button" data-action="close-modal">Cancel</button><button class="modal-button primary" data-action="confirm-rename">Save name</button>`);
}
function confirmRename() {
  const name = document.querySelector('#modal-name')?.value?.trim();
  if (!name) return toast('Scene name cannot be empty', 'error');
  const next = cloneValue(sceneData); next.scene.name = name.slice(0, 80); closeModal(); commitScene(next, { label: 'Scene renamed' });
}

function persistLocal() {
  try { storageSet('a3d-project-current', JSON.stringify({ scene: sceneData, code: codeArea?.value || '' })); storageSet('a3d-project-updated', new Date().toISOString()); } catch (error) { console.warn('Could not save scene locally', error); }
  const footer = document.querySelector('#footer-sync'); if (footer) footer.textContent = 'Saved in this browser';
}
function loadLocal() {
  try {
    const raw = storageGet('a3d-project-current');
    if (!raw) return null;
    const value = JSON.parse(raw);
    if (value?.scene?.version === 1 && Array.isArray(value.scene.objects)) return { ...value, scene: normalizeSceneData(value.scene) };
  } catch {}
  return null;
}
async function syncScene(source = 'browser', recordUndo = true) {
  const syncLabel = document.querySelector('#sync-label'); const syncDot = document.querySelector('#sync-dot');
  try {
    const response = await fetch(`/api/scenes/${encodeURIComponent(sessionId)}`, { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ scene: sceneData, clientId, source, recordUndo }) });
    if (!response.ok) throw new Error(`sync status ${response.status}`);
    if (syncLabel) syncLabel.textContent = wsStatus === 'online' ? 'Live sync connected' : 'Local changes synced';
    if (syncDot) syncDot.classList.add('online');
  } catch {
    if (syncLabel) syncLabel.textContent = 'Saved locally · sync unavailable';
    if (syncDot) syncDot.classList.remove('online');
  }
}
async function startSync() {
  try {
    const response = await fetch(`/api/scenes/${encodeURIComponent(sessionId)}`);
    if (response.ok) {
      const remote = await response.json();
      if (remote.scene) {
        sceneData = normalizeSceneData(remote.scene);
        selectedId = null;
        codeArea.value = sceneToCode(sceneData); updateEditorDecorations();
        renderScene3D({ resetCamera: true }); renderSidebar(); renderInspector(); updateSceneStats();
      }
    } else if (response.status === 404) await syncScene('browser-init', false);
  } catch { /* local mode remains usable without the bridge */ }
  const scheme = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  try {
    ws = new WebSocket(`${scheme}//${window.location.host}/sync?sessionId=${encodeURIComponent(sessionId)}&clientId=${encodeURIComponent(clientId)}`);
    ws.addEventListener('open', () => { wsStatus = 'online'; updateConnectionUI(); });
    ws.addEventListener('message', (event) => {
      try {
        const payload = JSON.parse(event.data);
        if (payload.type === 'scene:update' && payload.source !== clientId && payload.scene) {
          const previous = cloneValue(sceneData);
          const selectedStillExists = selectedId && findNode(payload.scene, selectedId);
          sceneData = normalizeSceneData(payload.scene);
          if (!selectedStillExists) selectedId = null;
          pushHistory(previous);
          codeArea.value = sceneToCode(sceneData); codeDirty = false; updateEditorDecorations();
          renderScene3D(); renderSidebar(); renderInspector(); updateSceneStats(); persistLocal();
          setRunStatus('Scene updated by connected AI', 'Remote scene changes arrived live', 'success');
          toast('Scene updated through MCP', 'info');
        }
      } catch (error) { console.warn('Ignored malformed sync event', error); }
    });
    ws.addEventListener('close', () => { wsStatus = 'offline'; updateConnectionUI(); setTimeout(startSyncSocket, 2200); });
    ws.addEventListener('error', () => { wsStatus = 'offline'; updateConnectionUI(); });
  } catch { wsStatus = 'offline'; updateConnectionUI(); }
}
function startSyncSocket() {
  if (ws && ws.readyState === WebSocket.OPEN) return;
  const scheme = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
  try {
    ws = new WebSocket(`${scheme}//${window.location.host}/sync?sessionId=${encodeURIComponent(sessionId)}&clientId=${encodeURIComponent(clientId)}`);
    ws.addEventListener('open', () => { wsStatus = 'online'; updateConnectionUI(); });
    ws.addEventListener('message', (event) => {
      try {
        const payload = JSON.parse(event.data);
        if (payload.type === 'scene:update' && payload.source !== clientId && payload.scene) {
          const previous = cloneValue(sceneData); sceneData = normalizeSceneData(payload.scene); pushHistory(previous);
          selectedId = selectedId && findNode(sceneData, selectedId) ? selectedId : null;
          codeArea.value = sceneToCode(sceneData); codeDirty = false; updateEditorDecorations();
          renderScene3D(); renderSidebar(); renderInspector(); updateSceneStats(); persistLocal();
          setRunStatus('Scene updated by connected AI', 'Remote scene changes arrived live', 'success'); toast('Scene updated through MCP', 'info');
        }
      } catch {}
    });
    ws.addEventListener('close', () => { wsStatus = 'offline'; updateConnectionUI(); setTimeout(startSyncSocket, 2600); });
    ws.addEventListener('error', () => { wsStatus = 'offline'; updateConnectionUI(); });
  } catch { wsStatus = 'offline'; updateConnectionUI(); }
}
function openMobilePanel(which) {
  if (window.innerWidth > 820) return;
  const left = document.querySelector('.left-panel');
  const right = document.querySelector('.inspector-panel');
  const backdrop = document.querySelector('#mobile-backdrop');
  left.classList.toggle('mobile-open', which === 'scene');
  right.classList.toggle('mobile-open', which === 'inspector');
  backdrop.classList.remove('hidden');
}
function closeMobilePanels() {
  document.querySelector('.left-panel')?.classList.remove('mobile-open');
  document.querySelector('.inspector-panel')?.classList.remove('mobile-open');
  document.querySelector('#mobile-backdrop')?.classList.add('hidden');
}
function updateConnectionUI() {
  const syncLabel = document.querySelector('#sync-label'); const syncDot = document.querySelector('#sync-dot');
  if (syncLabel) syncLabel.textContent = wsStatus === 'online' ? 'Live sync connected' : 'Saved locally · reconnecting';
  if (syncDot) syncDot.classList.toggle('online', wsStatus === 'online');
  const footer = document.querySelector('#footer-sync'); if (footer) footer.textContent = wsStatus === 'online' ? 'Live scene sync' : 'Local project';
  renderSidebar();
}
async function checkMcpServer() {
  try { const response = await fetch('/api/health'); if (!response.ok) throw new Error('offline'); await response.json(); mcpServerOnline = true; }
  catch { mcpServerOnline = false; }
  const title = document.querySelector('#mcp-pill-title'); const state = document.querySelector('#mcp-pill-state');
  if (title) title.textContent = mcpServerOnline ? 'Studio MCP server' : 'MCP offline';
  if (state) state.textContent = mcpServerOnline ? 'Session bridge ready' : 'Local editor only';
  document.querySelector('.connection-pill')?.classList.toggle('offline', !mcpServerOnline);
  if (currentSection === 'mcp') renderSidebar();
}

function openProjectFile() { document.querySelector('#project-file').click(); }
function newProject() {
  openModal('Start a new scene?', `<p class="modal-help">Your current scene is saved in this browser. A new empty scene will replace the active workspace.</p>`, `<button class="modal-button" data-action="close-modal">Cancel</button><button class="modal-button primary" data-action="confirm-new-scene">Create new scene</button>`);
}
function createEmptyProject() {
  closeModal();
  const next = createScene('Untitled Scene'); selectedId = null; expandedIds.clear();
  commitScene(next, { label: 'New scene', resetCamera: true });
  codeArea.value = ''; codeDirty = false; updateEditorDecorations(); persistLocal();
}
function saveProject() {
  persistLocal();
  let projects = [];
  try { projects = JSON.parse(storageGet('a3d-project-library') || '[]'); } catch {}
  const id = sceneData.scene?.name || 'Untitled Scene';
  projects = projects.filter((project) => project.name !== id);
  projects.unshift({ name: id, savedAt: new Date().toISOString(), scene: sceneData, code: codeArea.value });
  try { storageSet('a3d-project-library', JSON.stringify(projects.slice(0, 20))); } catch {}
  toast('Project saved to this browser', 'success');
}
function handleOpenFile(file) {
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    const text = String(reader.result || '');
    try {
      if (file.name.toLowerCase().endsWith('.json')) {
        const parsed = JSON.parse(text);
        const scene = normalizeSceneData(parsed.scene && parsed.scene.version === 1 ? parsed.scene : parsed);
        selectedId = null; commitScene(scene, { label: 'Project opened', resetCamera: true });
        codeArea.value = sceneToCode(scene); updateEditorDecorations(); toast('Project opened', 'success');
      } else {
        codeArea.value = text; updateEditorDecorations(); runCode();
      }
    } catch (error) { toast(error.message || 'Could not open this file', 'error'); }
  };
  reader.onerror = () => toast('Could not read that file', 'error');
  reader.readAsText(file);
}

function updateMaterialOnNode(next, node, patch) {
  if (typeof node.material === 'string') {
    const material = next.materials.find((item) => item.name === node.material);
    if (material) Object.assign(material, patch);
    else node.material = { ...getMaterialSpec(node.material), ...patch };
  } else node.material = { ...(node.material || {}), ...patch };
}
function applyInspectorChange(target) {
  if (target.matches('[data-transform]')) {
    const next = cloneValue(sceneData); const node = findNode(next, selectedId); if (!node) return;
    const key = target.dataset.transform; const axis = Number(target.dataset.axis); const value = Number(target.value);
    if (!Number.isFinite(value)) return;
    node[key][axis] = value;
    commitScene(next, { label: `${niceName(key)} updated`, regenerateCode: true });
    return;
  }
  if (target.matches('[data-geometry]')) {
    const next = cloneValue(sceneData); const node = findNode(next, selectedId); if (!node) return;
    const key = target.dataset.geometry; const value = Number(target.value); if (!Number.isFinite(value) || value <= 0) return;
    if (key === 'size') node.size[Number(target.dataset.axis)] = value; else node[key] = value;
    commitScene(next, { label: 'Geometry updated' }); return;
  }
  if (target.matches('[data-node-name]')) {
    const next = cloneValue(sceneData); const node = findNode(next, selectedId); if (!node) return; node.name = target.value.trim().slice(0, 80) || node.name; commitScene(next, { label: 'Object renamed' }); return;
  }
  if (target.matches('[data-inspector-light]')) {
    const next = cloneValue(sceneData); const node = findNode(next, selectedId); if (!node) return;
    const key = target.dataset.inspectorLight; const rawValue = target.type === 'range' ? Number(target.value) : target.value;
    if (key === 'color' && !/^#[0-9a-f]{6}$/i.test(rawValue)) return;
    node[key] = rawValue; commitScene(next, { label: 'Light updated' }); return;
  }
  if (target.matches('[data-inspector-material]')) {
    const key = target.dataset.inspectorMaterial; const rawValue = target.type === 'range' ? Number(target.value) : target.value;
    if (key.startsWith('environment.')) {
      const next = cloneValue(sceneData); const parts = key.split('.'); let cursor = next;
      for (let i = 0; i < parts.length - 1; i++) cursor = cursor[parts[i]];
      cursor[parts.at(-1)] = rawValue;
      if (key.endsWith('near') && cursor.far <= rawValue) cursor.far = rawValue + 10;
      if (key.endsWith('far') && cursor.near >= rawValue) cursor.near = Math.max(0, rawValue - 10);
      commitScene(next, { label: 'Environment updated' }); return;
    }
    const next = cloneValue(sceneData); const node = findNode(next, selectedId); if (!node) return;
    updateMaterialOnNode(next, node, { [key]: rawValue });
    commitScene(next, { label: 'Material updated' }); return;
  }
}
function toggleObjectValue(button) {
  if (button.dataset.materialToggle === 'true') {
    if (!selectedId) return;
    const next = cloneValue(sceneData); const node = findNode(next, selectedId); if (!node) return;
    const material = getMaterialSpec(node.material);
    const key = button.dataset.toggleKey;
    let patch;
    if (key === 'emissiveEnabled') patch = { emissive: material.emissive || '#ffc66d', emissiveIntensity: material.emissiveIntensity ? 0 : 1.5 };
    else if (key === 'transparent') patch = { transparent: !material.transparent, opacity: material.transparent ? 1 : Math.min(Number(material.opacity ?? 1), .55) };
    else patch = { [key]: !material[key] };
    updateMaterialOnNode(next, node, patch);
    commitScene(next, { label: 'Material updated' }); return;
  }
  const key = button.dataset.toggleKey;
  if (key.startsWith('environment.')) {
    const next = cloneValue(sceneData); const prop = key.split('.')[1]; next.environment[prop] = !next.environment[prop]; commitScene(next, { label: 'Environment updated' }); return;
  }
  const next = cloneValue(sceneData); const node = findNode(next, selectedId); if (!node) return;
  if (key === 'emissiveEnabled') {
    const material = getMaterialSpec(node.material); updateMaterialOnNode(next, node, { emissive: material.emissive || '#ffc66d', emissiveIntensity: material.emissiveIntensity ? 0 : 1.5 });
  } else node[key] = !node[key];
  commitScene(next, { label: `${niceName(key)} toggled` });
}
function applyMaterialFromLibrary(name) {
  if (!selectedId) return;
  const next = cloneValue(sceneData); const node = findNode(next, selectedId); if (!node) return;
  if (node.type === 'group') {
    const applyToMeshes = (current) => { for (const child of current.children || []) { if (child.type === 'group') applyToMeshes(child); else if (!LIGHT_TYPES.includes(child.type)) child.material = name; } };
    applyToMeshes(node);
  } else node.material = name;
  commitScene(next, { label: `${name} applied` });
}
function addNewMaterial() {
  openModal('Create material', `<label class="modal-field"><span>MATERIAL NAME</span><input id="modal-material-name" maxlength="80" value="Material ${sceneData.materials.length + 1}"></label><p class="modal-help">A shared finish can be assigned to any mesh in the material library.</p>`, `<button class="modal-button" data-action="close-modal">Cancel</button><button class="modal-button primary" data-action="confirm-material">Create material</button>`);
}
function confirmMaterial() {
  const name = document.querySelector('#modal-material-name')?.value?.trim();
  if (!name) return toast('Material name cannot be empty', 'error');
  const next = cloneValue(sceneData); const material = { name: name.slice(0, 80), color: '#a9b9cd', metalness: .25, roughness: .48 };
  next.materials.push(material); closeModal(); commitScene(next, { label: 'Material created' });
}
function openModal(title, body, footer) {
  const root = document.querySelector('#app-modal-root');
  root.innerHTML = `<div class="modal-backdrop" data-modal-dismiss><section class="app-modal" role="dialog" aria-modal="true" aria-label="${escapeHtml(title)}"><header><div><span class="section-eyebrow">AI 3D STUDIO</span><h2>${escapeHtml(title)}</h2></div><button class="quiet-icon-button" data-action="close-modal" aria-label="Close">${icon('close', 15)}</button></header><div class="modal-body">${body}</div><footer>${footer}</footer></section></div>`;
  const backdrop = root.querySelector('.modal-backdrop');
  backdrop.addEventListener('click', (event) => { if (event.target === backdrop) closeModal(); });
  setTimeout(() => root.querySelector('input')?.focus(), 40);
}
function closeModal() { document.querySelector('#app-modal-root').innerHTML = ''; }
function viewJson() {
  openModal('Scene JSON', `<p class="modal-help">Validated scene data · ${countObjects(sceneData)} objects · version ${sceneData.version}</p><pre class="modal-json">${escapeHtml(JSON.stringify(sceneData, null, 2))}</pre>`, `<button class="modal-button" data-action="close-modal">Close</button><button class="modal-button primary" data-action="copy-json">${icon('copy', 13)}Copy JSON</button>`);
}

function handleClick(event) {
  const target = event.target.closest('button,[data-section],[data-inspector-tab]');
  if (!target) return;
  if (target.dataset.section) { currentSection = target.dataset.section; renderSidebar(); return; }
  if (target.dataset.inspectorTab) { inspectorTab = target.dataset.inspectorTab; renderInspector(); return; }
  if (target.dataset.toggleKey) { toggleObjectValue(target); return; }
  const action = target.dataset.action;
  if (!action && target.dataset.tool) { setToolMode(target.dataset.tool); return; }
  if (target.dataset.tool) { setToolMode(target.dataset.tool); return; }
  switch (action) {
    case 'new': newProject(); break;
    case 'open': openProjectFile(); break;
    case 'save': saveProject(); break;
    case 'undo': undo(); break;
    case 'redo': redo(); break;
    case 'run': runCode(); break;
    case 'export-menu': document.querySelector('#export-menu').classList.toggle('hidden'); break;
    case 'export-glb': document.querySelector('#export-menu').classList.add('hidden'); exportGlb(); break;
    case 'export-json': document.querySelector('#export-menu').classList.add('hidden'); exportJson(); break;
    case 'export-code': document.querySelector('#export-menu').classList.add('hidden'); exportCode(); break;
    case 'format': try { codeArea.value = formatSceneCode(codeArea.value); codeDirty = true; updateEditorDecorations(); hideCodeMessage(); toast('Scene code formatted', 'success'); } catch (error) { codeMessage(error.message); } break;
    case 'clear-code': codeArea.value = ''; codeDirty = true; updateEditorDecorations(); hideCodeMessage(); break;
    case 'copy-code': copyText(codeArea.value, 'Scene code copied'); break;
    case 'download-code': exportCode(); break;
    case 'toggle-code': codeExpanded = !codeExpanded; document.querySelector('#code-dock').classList.toggle('expanded', codeExpanded); setTimeout(() => window.dispatchEvent(new Event('resize')), 120); break;
    case 'select-node': selectObject(target.dataset.id); break;
    case 'expand-node': { const id = target.dataset.id; if (expandedIds.has(id)) expandedIds.delete(id); else expandedIds.add(id); renderSidebar(); break; }
    case 'toggle-visible': { const next = cloneValue(sceneData); const node = findNode(next, target.dataset.id); if (node) { node.visible = node.visible === false; commitScene(next, { label: node.visible ? 'Object shown' : 'Object hidden' }); } break; }
    case 'select-scene': selectObject(null); break;
    case 'add-menu': addPrimitive('box'); break;
    case 'add-cube': addPrimitive('box'); break;
    case 'add-sphere': addPrimitive('sphere'); break;
    case 'add-cylinder': addPrimitive('cylinder'); break;
    case 'add-light': addLight(); break;
    case 'add-group': addGroup(); break;
    case 'delete-selected': deleteSelected(); break;
    case 'duplicate-selected': duplicateSelected(); break;
    case 'focus-selected': frameSelected(true); break;
    case 'frame-selected': frameSelected(true); break;
    case 'toggle-grid': toggleGrid(); break;
    case 'camera-menu': cycleCameraPreset(); break;
    case 'mobile-scene': openMobilePanel('scene'); break;
    case 'mobile-inspector': openMobilePanel('inspector'); break;
    case 'copy-prompt': copyText(MASTER_PROMPT, 'Master Prompt copied'); break;
    case 'example-cube': loadCodeExample('cube'); break;
    case 'example-chair': loadCodeExample('chair'); break;
    case 'copy-mcp-url': copyText(mcpEndpoint(), 'MCP URL copied'); break;
    case 'copy-mcp-setup': copyText(mcpSetupInstructions(), 'MCP setup instructions copied'); break;
    case 'test-mcp': checkMcpServer().then(() => toast(mcpServerOnline ? 'Studio MCP endpoint is responding' : 'Could not reach the MCP endpoint', mcpServerOnline ? 'success' : 'error')); break;
    case 'open-mcp': currentSection = 'mcp'; renderSidebar(); break;
    case 'settings': toast('Studio settings are in the Inspector and Environment tabs', 'info'); break;
    case 'dismiss-code-message': hideCodeMessage(); break;
    case 'view-json': viewJson(); break;
    case 'close-modal': closeModal(); break;
    case 'copy-json': copyText(JSON.stringify(sceneData, null, 2), 'Scene JSON copied'); break;
    case 'confirm-new-scene': createEmptyProject(); break;
    case 'confirm-rename': confirmRename(); break;
    case 'confirm-material': confirmMaterial(); break;
    case 'toggle-section': { const section = document.getElementById(target.dataset.id); if (section) { section.classList.toggle('collapsed'); target.classList.toggle('collapsed'); } break; }
    case 'select-material': inspectorTab = 'materials'; renderInspector(); break;
    case 'add-material': addNewMaterial(); break;
    case 'apply-material': applyMaterialFromLibrary(target.dataset.materialName); break;
    case 'rename-scene': renameScene(); break;
    default:
      if (target.dataset.materialName) applyMaterialFromLibrary(target.dataset.materialName);
  }
}

app.addEventListener('click', handleClick);
app.addEventListener('change', (event) => {
  const target = event.target;
  if (target.id === 'project-file') return;
  if (target.matches('[data-transform],[data-geometry],[data-node-name],[data-inspector-material]')) applyInspectorChange(target);
  if (target.matches('[data-toggle-key]')) toggleObjectValue(target);
  if (target.id === 'scene-search') { searchTerm = target.value; renderSidebar(); const input = document.querySelector('#scene-search'); input?.focus(); input?.setSelectionRange(searchTerm.length, searchTerm.length); }
});
app.addEventListener('input', (event) => {
  const target = event.target;
  if (target === codeArea) { codeDirty = true; updateEditorDecorations(); hideCodeMessage(); }
  else if (target.id === 'scene-search') { searchTerm = target.value; renderSidebar(); const input = document.querySelector('#scene-search'); input?.focus(); input?.setSelectionRange(searchTerm.length, searchTerm.length); }
  else if (target.matches('input[type="range"][data-inspector-material],input[type="range"][data-inspector-light]')) { const output = target.closest('.slider-property')?.querySelector('output'); if (output) output.value = fmt(target.value, target.dataset.inspectorLight ? 1 : 2); }
});
app.addEventListener('scroll', (event) => { if (event.target === codeArea) { highlight.scrollTop = codeArea.scrollTop; highlight.scrollLeft = codeArea.scrollLeft; gutter.scrollTop = codeArea.scrollTop; } }, true);
app.addEventListener('keydown', (event) => {
  if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 's') { event.preventDefault(); saveProject(); }
  if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'z') { event.preventDefault(); event.shiftKey ? redo() : undo(); }
  if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'enter') { event.preventDefault(); runCode(); }
  if (event.target === codeArea && event.key === 'Tab') { event.preventDefault(); const start = codeArea.selectionStart; const end = codeArea.selectionEnd; codeArea.value = codeArea.value.slice(0, start) + '  ' + codeArea.value.slice(end); codeArea.selectionStart = codeArea.selectionEnd = start + 2; codeDirty = true; updateEditorDecorations(); }
  if (event.target === document.body || event.target === app) {
    if (event.key.toLowerCase() === 'w') setToolMode('translate');
    if (event.key.toLowerCase() === 'e') setToolMode('rotate');
    if (event.key.toLowerCase() === 'r') setToolMode('scale');
    if (event.key === 'Delete' || event.key === 'Backspace') deleteSelected();
  }
});
document.querySelector('#project-file').addEventListener('change', (event) => { handleOpenFile(event.target.files?.[0]); event.target.value = ''; });
document.querySelector('#mobile-backdrop').addEventListener('click', closeMobilePanels);
document.addEventListener('click', (event) => { if (!event.target.closest('.export-wrap')) document.querySelector('#export-menu')?.classList.add('hidden'); });

initThree();
const localProject = loadLocal();
if (localProject?.scene) {
  sceneData = cloneValue(localProject.scene);
  if (localProject.code) codeArea.value = localProject.code; else codeArea.value = sceneToCode(sceneData);
  selectedId = null;
  renderScene3D({ resetCamera: true });
} else {
  sceneData = createDemoScene();
  codeArea.value = sceneToCode(sceneData);
  expandedIds = new Set(sceneData.objects.filter((node) => node.type === 'group').map((node) => node.id));
  const defaultHouse = sceneData.objects.find((node) => node.name === 'House'); selectedId = defaultHouse?.id || null;
  renderScene3D({ resetCamera: true });
  persistLocal();
}
updateEditorDecorations();
renderSidebar();
renderInspector();
updateSceneStats();
updateUndoButtons();
startSync();
checkMcpServer();
