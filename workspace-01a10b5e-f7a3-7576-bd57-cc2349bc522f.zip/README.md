# AI 3D Studio

A browser-based Three.js scene editor with a typed, literal-only Scene API and a remote Model Context Protocol (MCP) server. The standalone editor works without an AI provider or credentials; MCP is an optional direct-control path.

## Run locally

```bash
npm install
npm run dev
```

Open the URL printed by Vite (default `http://localhost:5173`). The editor starts with an editable Alpine Glass House demo. Use **Run** to validate and render the code in the bottom editor, click hierarchy items to select them, and use the Inspector to adjust transforms/materials. Projects are saved in this browser's local storage.

```bash
npm test
npm run build
```

## Scene API safety

Scene code is tokenized and parsed into data. It is **not** evaluated as JavaScript. The parser accepts only documented function calls and literal strings, numbers, booleans, arrays, and objects. It rejects unknown commands, prototype-related object keys, invalid geometry values, and scenes over 500 objects. Procedural commands are capped at 200 instances.

Core types, schemas, validation, parsing, and serialization are in `shared/scene-core.js` and shared by the browser and MCP server.

## MCP endpoint

The server exposes MCP Streamable HTTP at:

```text
https://YOUR_PUBLIC_DOMAIN/mcp?sessionId=YOUR_SCENE_SESSION_ID
```

The app's **MCP** tab shows the current scene-scoped URL and tool catalog. The server currently provides tools for reading a scene, adding/updating/deleting/duplicating objects, transforms/materials, grouping, lighting, environment edits, validated Scene API code, undo/redo, and JSON/code exports. MCP updates are pushed into an open browser via WebSocket at `/sync`.

For local testing, MCP clients can use `http://localhost:5173/mcp?sessionId=<session-id>`; public ChatGPT connections need a stable public HTTPS deployment. The `/mcp` URL contains an unguessable per-scene capability ID: treat it like a secret.

### Production hardening required

This repository is a runnable starter, **not a turnkey public SaaS**. Before exposing it to the internet:

- Deploy behind HTTPS and set `MCP_API_TOKEN` (the server checks bearer tokens when this variable is configured).
- For a ChatGPT custom app, implement the OAuth authorization/resource-server flow required by the target ChatGPT surface; a static bearer token is only suitable for controlled MCP-client testing and may not be accepted by ChatGPT's app connection flow.
- Replace the in-memory scene store with a database/shared session store and add durable ownership, expiry, quotas, rate limits, audit logs, and CSRF/CORS/origin policy appropriate to the deployment.
- Use your own stable domain. The Arena preview host is temporary and may not be reachable by third-party MCP clients.
- Validate current ChatGPT plan, workspace, and device availability before promising write access. The standalone editor and copy/paste workflow remain independent of MCP.

The MCP server is a tool server; an embedded ChatGPT Apps SDK 3D widget and production OAuth registration are not included in this starter. Where a host does not support interactive app UI, the standard MCP tools still work.

## Structure

```text
src/main.js                 Browser shell, Three.js renderer, editor and inspector
src/styles.css              Responsive dark studio UI
shared/scene-core.js        Shared scene model, safe parser, API docs, master prompt
server.mjs                  Express API, WebSocket sync, Streamable HTTP MCP server
 tests/scene-core.test.js   Parser and scene-core tests
```

## MCP session and tools

Each browser has a random local scene session. The MCP endpoint is scoped to that session through its URL parameter, so tool calls from that endpoint edit the matching open browser scene. Do not share the URL. The development server stores scenes in memory; the browser also saves a project copy in local storage.

Available tools include `get_scene`, `list_objects`, `get_object`, `get_selected_object`, `create_scene`, `clear_scene`, `add_object`, `update_object`, `set_transform`, `set_material`, `delete_object`, `duplicate_object`, `create_group`, `add_to_group`, `add_light`, `set_environment`, `run_scene_code`, `undo`, `redo`, and `export_scene`.
