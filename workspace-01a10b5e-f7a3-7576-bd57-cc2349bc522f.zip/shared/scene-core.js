export const PRIMITIVE_TYPES = ['box', 'sphere', 'cylinder', 'cone', 'torus', 'capsule', 'plane', 'circle', 'ring'];
export const LIGHT_TYPES = ['directionalLight', 'pointLight', 'spotLight', 'hemisphereLight'];
export const NODE_TYPES = [...PRIMITIVE_TYPES, 'group', ...LIGHT_TYPES];
export const MAX_OBJECTS = 500;
export const MAX_REPEAT = 200;

export const MASTER_PROMPT = `You are an expert 3D artist and procedural modeler creating scenes for AI 3D Studio.

Convert the user's request into valid AI 3D Studio Scene API code. Output ONLY Scene API commands: no Markdown, code fences, explanations, imports, variables, or arbitrary JavaScript.

SAFETY: Use only the documented commands below. Never use eval, functions, DOM APIs, Three.js, imports, network requests, or invented commands. Arguments must be literal strings, numbers, booleans, arrays, and objects. Never use expressions, loops, variables, or callbacks.

COORDINATES: X is left/right, Y is up/down, Z is forward/back. One unit is one meter. Ground is Y=0. Objects should rest on the ground unless requested otherwise. Use radians for rotations.

ART DIRECTION: Think through proportions, hierarchy, contact with the ground, camera composition, materials, lighting, and shadows. Give every object a clear name. Build recognizable objects from multiple coordinated parts rather than a single primitive. Reuse materials and use deterministic placements. Prefer a concise, well-organized scene over excessive geometry.

SUPPORTED COMMANDS:
createBox({name,size:[2,2,2],position:[0,1,0],rotation:[0,0,0],scale:[1,1,1],material:{color:"#d8a56d",metalness:0,roughness:0.5}})
createSphere({name:"Sphere",radius:1,position:[0,1,0],material:{color:"#6688cc"}})
createCylinder({name:"Cylinder",radiusTop:0.5,radiusBottom:0.5,height:1,position:[0,0.5,0]})
createCone({name:"Cone",radius:0.5,height:1,position:[0,0.5,0]})
createTorus({name:"Ring",radius:0.7,tube:0.18,position:[0,1,0]})
createCapsule({name:"Capsule",radius:0.35,length:0.7,position:[0,1,0]})
createPlane({name:"Plane",size:[4,4],position:[0,0,0]})
createCircle({name:"Circle",radius:1,position:[0,0,0]})
createRing({name:"Ring",innerRadius:0.25,outerRadius:0.5,position:[0,0,0]})
group({name:"Assembly",position:[0,0,0],children:[{type:"box",name:"Part",size:[1,1,1],position:[0,0.5,0]}]})
createMaterial({name:"Steel",color:"#aabbd0",metalness:0.9,roughness:0.2})
directionalLight({name:"Sun",color:"#ffffff",intensity:2,position:[8,14,7],castShadow:true})
pointLight({name:"Lamp",color:"#ffc982",intensity:18,distance:24,position:[0,4,0]})
spotLight({name:"Spot",color:"#ffffff",intensity:30,position:[2,6,2],target:[0,0,0],angle:0.4,castShadow:true})
hemisphereLight({name:"Sky fill",skyColor:"#dbeafe",groundColor:"#6b5842",intensity:1})
environment({background:"#a7c5d8",fog:{color:"#a7c5d8",near:50,far:180},grid:false,ground:true,intensity:1})
camera({position:[14,11,18],target:[0,2,0],fov:42})
repeat({count:5,step:[2,0,0],start:[-4,0,0],object:{type:"box",name:"Block",size:[1,1,1]}})
grid({columns:4,rows:3,spacing:[2,2],center:[0,0,0],object:{type:"sphere",name:"Orb",radius:0.4}})
scatter({count:24,area:[18,18],seed:42,object:{type:"cone",name:"Pine",radius:0.7,height:3}})
setPosition({name:"Cube",position:[0,1,0]})
setRotation({name:"Cube",rotation:[0,1.57,0]})
setScale({name:"Cube",scale:[1,1,1]})
setMaterial({name:"Cube",material:{color:"#ff0000",metalness:0.2,roughness:0.5}})
deleteObject({name:"Cube"})
clearScene()

Every command takes a single object argument except clearScene(). Geometry and transform values must be finite numbers. Keep total objects under 500 and procedural counts under 200. Use hexadecimal colors such as "#d8a56d". API calls are parsed as data and never execute JavaScript.

Example:
environment({background:"#b8c9d4",fog:{color:"#b8c9d4",near:50,far:180},ground:true});
directionalLight({name:"Warm key",color:"#ffe1b5",intensity:2,position:[8,14,7],castShadow:true});
createBox({name:"Red Cube",size:[2,2,2],position:[0,1,0],material:{color:"#ef4444",metalness:0,roughness:0.48}});`;

export const API_REFERENCE = [
  { title: 'Geometry', description: 'Create boxes, spheres, cylinders, cones, toruses, capsules, planes, circles, and rings. Use meters; size arrays are [X, Y, Z].', example: 'createBox({name:"Cube",size:[2,2,2],position:[0,1,0]});' },
  { title: 'Groups & hierarchy', description: 'Use group() with a children array to make assemblies. Select, transform, duplicate, and organize complete groups.', example: 'group({name:"Chair",children:[{type:"box",name:"Seat",size:[1.4,0.2,1.3],position:[0,1,0]}]});' },
  { title: 'Materials', description: 'PBR controls: color, metalness, roughness, opacity, transparency, emissive color, and emissive intensity.', example: 'createMaterial({name:"Brushed steel",color:"#b7c1ca",metalness:0.88,roughness:0.24});' },
  { title: 'Lighting', description: 'Directional, point, spot, and hemisphere lights. Shadow casting is available on directional and spot lights.', example: 'directionalLight({name:"Sun",color:"#ffe6c2",intensity:2,position:[8,12,6],castShadow:true});' },
  { title: 'Environment', description: 'Set background, fog, ground visibility, viewport grid, and overall lighting intensity.', example: 'environment({background:"#a7c5d8",fog:{color:"#a7c5d8",near:50,far:180},grid:false});' },
  { title: 'Procedural tools', description: 'Generate repeat, grid, and deterministic scatter patterns. Limits protect the browser from unexpectedly large scenes.', example: 'scatter({count:24,area:[18,18],seed:42,object:{type:"cone",name:"Pine",radius:0.7,height:3}});' },
  { title: 'Camera & transforms', description: 'Camera coordinates and object transforms use [x,y,z]; rotations use radians.', example: 'camera({position:[14,11,18],target:[0,2,0],fov:42});' }
];

export function createId(prefix = 'obj') {
  const token = globalThis.crypto?.randomUUID?.().replaceAll('-', '').slice(0, 10) || Math.random().toString(36).slice(2, 12);
  return `${prefix}_${token}`;
}
export function createScene(name = 'Untitled Scene') {
  return { version: 1, scene: { name: String(name || 'Untitled Scene').slice(0, 80) }, objects: [], materials: [], environment: { background: '#b8c9d4', fog: { color: '#b8c9d4', near: 80, far: 220 }, ground: true, grid: false, intensity: 1 }, camera: { position: [16, 12, 19], target: [0, 2.8, 0], fov: 42 } };
}
export function cloneValue(value) { return JSON.parse(JSON.stringify(value)); }
export function walkNodes(nodes, callback, parent = null) {
  for (const node of nodes || []) { callback(node, parent); walkNodes(node.children || [], callback, node); }
}
export function findNode(scene, query) {
  if (!scene || query == null) return null;
  const value = String(query).trim(); let found = null;
  walkNodes(scene.objects, (node) => { if (!found && (node.id === value || String(node.name).toLowerCase() === value.toLowerCase())) found = node; });
  return found;
}
export function countObjects(scene) { let count = 0; walkNodes(scene?.objects, () => count++); return count; }
function number(value, label, { min = -10000, max = 10000, fallback = 0 } = {}) {
  if (value == null) return fallback;
  const v = Number(value);
  if (!Number.isFinite(v) || v < min || v > max) throw new Error(`${label} must be a finite number between ${min} and ${max}.`);
  return v;
}
function vector(value, label, fallback, { min = -10000, max = 10000, scale = false } = {}) {
  if (value == null) return [...fallback];
  if (!Array.isArray(value) || value.length !== 3) throw new Error(`${label} must contain exactly 3 numbers.`);
  return value.map((v, i) => number(v, `${label}[${i}]`, { min: scale ? 0.001 : min, max, fallback: fallback[i] }));
}
export function validateColor(value, label = 'Color') {
  if (value == null) return '#ffffff';
  const color = String(value).trim();
  if (!/^(#[\da-f]{3}|#[\da-f]{6}|#[\da-f]{8}|white|black|red|green|blue|yellow|orange|purple|pink|cyan|magenta|gray|grey|gold|silver|transparent)$/i.test(color)) throw new Error(`${label} must be a supported color or hexadecimal value.`);
  return color;
}
export function normalizeMaterial(input = {}) {
  if (typeof input === 'string') return input.slice(0, 80);
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('Material must be an object or material name.');
  const result = { ...input };
  if (result.name != null) result.name = String(result.name).slice(0, 80);
  if (result.color != null) result.color = validateColor(result.color, 'Material color');
  if (result.emissive != null) result.emissive = validateColor(result.emissive, 'Emissive color');
  for (const key of ['metalness', 'roughness', 'opacity', 'emissiveIntensity', 'clearcoat', 'clearcoatRoughness', 'transmission', 'ior', 'thickness']) {
    if (result[key] != null) result[key] = number(result[key], `Material ${key}`, { min: 0, max: key === 'ior' ? 4 : key === 'emissiveIntensity' ? 20 : key === 'thickness' ? 100 : 1, fallback: 0 });
  }
  for (const key of ['transparent', 'wireframe', 'flatShading']) if (result[key] != null) result[key] = Boolean(result[key]);
  return result;
}

const GEOMETRY_DEFAULTS = {
  box: { size: [1, 1, 1] }, sphere: { radius: 0.5, widthSegments: 32, heightSegments: 20 },
  cylinder: { radiusTop: 0.5, radiusBottom: 0.5, height: 1, radialSegments: 24 }, cone: { radius: 0.5, height: 1, radialSegments: 24 },
  torus: { radius: 0.7, tube: 0.18, radialSegments: 12, tubularSegments: 48 }, capsule: { radius: 0.35, length: 0.7, capSegments: 8, radialSegments: 16 },
  plane: { size: [1, 1] }, circle: { radius: 0.5, segments: 32 }, ring: { innerRadius: 0.25, outerRadius: 0.5, segments: 32 }, group: {},
  directionalLight: { color: '#ffffff', intensity: 1, castShadow: true }, pointLight: { color: '#ffffff', intensity: 20, distance: 0, decay: 2 },
  spotLight: { color: '#ffffff', intensity: 80, distance: 0, angle: 0.4, penumbra: 0.2, decay: 2 }, hemisphereLight: { color: '#dbeafe', groundColor: '#6b5842', intensity: 1 }
};
function normalizeGeometry(type, spec) {
  const out = { ...(GEOMETRY_DEFAULTS[type] || {}) };
  const positive = (key, min = 0.001, max = 10000) => { if (spec[key] != null) out[key] = number(spec[key], `${type}.${key}`, { min, max, fallback: out[key] }); };
  if (type === 'box') {
    const size = spec.size ?? out.size; if (!Array.isArray(size) || size.length !== 3) throw new Error('Box size must contain exactly 3 numbers.');
    out.size = size.map((v, i) => number(v, `box.size[${i}]`, { min: 0.001, max: 10000, fallback: 1 }));
  } else if (type === 'plane') {
    const size = spec.size ?? out.size; if (!Array.isArray(size) || size.length !== 2) throw new Error('Plane size must contain exactly 2 numbers.');
    out.size = size.map((v, i) => number(v, `plane.size[${i}]`, { min: 0.001, max: 10000, fallback: 1 }));
  } else if (type === 'sphere') { positive('radius'); positive('widthSegments', 3, 128); positive('heightSegments', 2, 128); }
  else if (type === 'cylinder') { positive('radiusTop'); positive('radiusBottom'); positive('height'); positive('radialSegments', 3, 128); }
  else if (type === 'cone') { positive('radius'); positive('height'); positive('radialSegments', 3, 128); }
  else if (type === 'torus') { positive('radius'); positive('tube'); positive('radialSegments', 3, 128); positive('tubularSegments', 3, 256); }
  else if (type === 'capsule') { positive('radius'); positive('length', 0, 10000); positive('capSegments', 1, 64); positive('radialSegments', 3, 128); }
  else if (type === 'circle') { positive('radius'); positive('segments', 3, 128); }
  else if (type === 'ring') { positive('innerRadius'); positive('outerRadius'); positive('segments', 3, 128); if (out.innerRadius >= out.outerRadius) throw new Error('Ring innerRadius must be smaller than outerRadius.'); }
  return out;
}
export function createNode(type, input = {}, depth = 0) {
  if (depth > 64) throw new Error('Object hierarchy is too deeply nested (maximum depth: 64).');
  if (!NODE_TYPES.includes(type)) throw new Error(`Unsupported object type "${type}".`);
  const spec = input && typeof input === 'object' && !Array.isArray(input) ? input : {};
  const node = { id: typeof spec.id === 'string' && spec.id.length <= 80 ? spec.id : createId(type === 'group' ? 'group' : 'obj'), name: String(spec.name || (type === 'group' ? 'Group' : type)).slice(0, 80), type, position: vector(spec.position, 'Position', [0, 0, 0]), rotation: vector(spec.rotation, 'Rotation', [0, 0, 0]), scale: vector(spec.scale, 'Scale', [1, 1, 1], { scale: true, max: 1000 }), visible: spec.visible !== false, castShadow: spec.castShadow !== false, receiveShadow: spec.receiveShadow !== false, children: [] };
  if (type === 'group') {
    if (Array.isArray(spec.children)) {
      if (spec.children.length > MAX_OBJECTS) throw new Error(`Group children limit exceeded (${MAX_OBJECTS}).`);
      node.children = spec.children.map((child) => createNode(child.type || 'box', child, depth + 1));
    }
  } else if (!LIGHT_TYPES.includes(type)) {
    Object.assign(node, normalizeGeometry(type, spec));
    node.material = spec.material == null ? { color: '#c8d2dc', metalness: 0.05, roughness: 0.65 } : normalizeMaterial(spec.material);
    if (spec.animation && typeof spec.animation === 'object') node.animation = { ...spec.animation };
  } else {
    node.color = validateColor(spec.color ?? spec.skyColor ?? '#ffffff', 'Light color');
    node.intensity = number(spec.intensity, 'Light intensity', { min: 0, max: 1000, fallback: GEOMETRY_DEFAULTS[type].intensity });
    if (type === 'pointLight' || type === 'spotLight') { node.distance = number(spec.distance, 'Light distance', { min: 0, max: 10000, fallback: 0 }); node.decay = number(spec.decay, 'Light decay', { min: 0, max: 8, fallback: 2 }); }
    if (type === 'spotLight') { node.angle = number(spec.angle, 'Spot angle', { min: 0.01, max: Math.PI / 2, fallback: 0.4 }); node.penumbra = number(spec.penumbra, 'Spot penumbra', { min: 0, max: 1, fallback: 0.2 }); node.target = vector(spec.target, 'Spot target', [0, 0, 0]); }
    if (type === 'hemisphereLight') node.groundColor = validateColor(spec.groundColor ?? '#6b5842', 'Ground color');
    node.castShadow = Boolean(spec.castShadow);
  }
  return node;
}
export function addNode(scene, node, parentQuery = null) {
  if (countObjects(scene) + countTree(node) > MAX_OBJECTS) throw new Error(`Object count limit exceeded (${MAX_OBJECTS}).`);
  if (parentQuery) { const parent = findNode(scene, parentQuery); if (!parent || parent.type !== 'group') throw new Error(`Parent group "${parentQuery}" was not found.`); parent.children.push(node); }
  else scene.objects.push(node);
  return node;
}
function countTree(node) { let count = 0; walkNodes([node], () => count++); return count; }
export function removeNode(scene, query) {
  const value = String(query ?? '');
  const search = (nodes) => { const index = nodes.findIndex((node) => node.id === value || node.name.toLowerCase() === value.toLowerCase()); if (index >= 0) return nodes.splice(index, 1)[0]; for (const node of nodes) { const deleted = search(node.children || []); if (deleted) return deleted; } return null; };
  return search(scene.objects);
}
export function duplicateNode(scene, query) {
  const node = findNode(scene, query); if (!node) throw new Error(`Object "${query}" was not found.`);
  const copy = cloneValue(node);
  const regenerate = (current) => { current.id = createId(current.type === 'group' ? 'group' : 'obj'); current.name = `${current.name} Copy`; current.children = (current.children || []).map((child) => { const next = cloneValue(child); regenerate(next); return next; }); };
  regenerate(copy); copy.position[0] += 1.25; addNode(scene, copy); return copy;
}
export function updateNode(scene, query, patch) {
  const node = findNode(scene, query); if (!node) throw new Error(`Object "${query}" was not found.`);
  if (patch.position != null) node.position = vector(patch.position, 'Position', node.position);
  if (patch.rotation != null) node.rotation = vector(patch.rotation, 'Rotation', node.rotation);
  if (patch.scale != null) node.scale = vector(patch.scale, 'Scale', node.scale, { scale: true, max: 1000 });
  if (patch.material != null) node.material = normalizeMaterial(patch.material);
  if (patch.visible != null) node.visible = Boolean(patch.visible);
  return node;
}

export class SceneCodeError extends Error {
  constructor(message, line = 1, column = 1) { super(`Line ${line}, column ${column}: ${message}`); this.name = 'SceneCodeError'; this.line = line; this.column = column; }
}
function tokenize(source) {
  const tokens = []; let i = 0, line = 1, column = 1;
  const advance = () => { const ch = source[i++]; if (ch === '\n') { line++; column = 1; } else column++; return ch; };
  while (i < source.length) {
    const ch = source[i];
    if (/\s/.test(ch)) { advance(); continue; }
    if (ch === '/' && source[i + 1] === '/') { while (i < source.length && advance() !== '\n') {} continue; }
    if (ch === '/' && source[i + 1] === '*') { const startLine = line, startColumn = column; advance(); advance(); let closed = false; while (i < source.length) { if (source[i] === '*' && source[i + 1] === '/') { advance(); advance(); closed = true; break; } advance(); } if (!closed) throw new SceneCodeError('Unclosed block comment.', startLine, startColumn); continue; }
    const start = { line, column };
    if (/[A-Za-z_$]/.test(ch)) { let value = ''; while (i < source.length && /[A-Za-z0-9_$]/.test(source[i])) value += advance(); tokens.push({ type: 'identifier', value, ...start }); continue; }
    if (ch === '"' || ch === "'") {
      const quote = advance(); let value = '', closed = false;
      while (i < source.length) { const current = advance(); if (current === quote) { closed = true; break; } if (current === '\\') { if (i >= source.length) break; const esc = advance(); const simple = { n: '\n', r: '\r', t: '\t', b: '\b', f: '\f', '\\': '\\', '"': '"', "'": "'" }; if (esc === 'u') { const hex = source.slice(i, i + 4); if (!/^[\da-f]{4}$/i.test(hex)) throw new SceneCodeError('Invalid Unicode escape.', line, column); for (let j = 0; j < 4; j++) advance(); value += String.fromCharCode(parseInt(hex, 16)); } else value += simple[esc] ?? esc; } else value += current; }
      if (!closed) throw new SceneCodeError('Unterminated string.', start.line, start.column); tokens.push({ type: 'string', value, ...start }); continue;
    }
    if (ch === '-' || /\d/.test(ch)) { const match = source.slice(i).match(/^-?(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?/); if (!match) throw new SceneCodeError('Invalid number.', line, column); const raw = match[0]; for (let j = 0; j < raw.length; j++) advance(); const value = Number(raw); if (!Number.isFinite(value)) throw new SceneCodeError('Numbers must be finite.', start.line, start.column); tokens.push({ type: 'number', value, ...start }); continue; }
    if ('{}[](),:;'.includes(ch)) { tokens.push({ type: ch, value: advance(), ...start }); continue; }
    throw new SceneCodeError(`Unsupported character "${ch}". Use literal data only.`, line, column);
  }
  tokens.push({ type: 'eof', value: '', line, column }); return tokens;
}
const COMMAND_TO_TYPE = { createBox: 'box', createSphere: 'sphere', createCylinder: 'cylinder', createCone: 'cone', createTorus: 'torus', createCapsule: 'capsule', createPlane: 'plane', createCircle: 'circle', createRing: 'ring', group: 'group', directionalLight: 'directionalLight', pointLight: 'pointLight', spotLight: 'spotLight', hemisphereLight: 'hemisphereLight' };
export const SUPPORTED_COMMANDS = [...Object.keys(COMMAND_TO_TYPE), 'createMaterial', 'createTexture', 'environment', 'camera', 'repeat', 'grid', 'scatter', 'setPosition', 'setRotation', 'setScale', 'setMaterial', 'deleteObject', 'duplicate', 'clone', 'clearScene'];
export function parseSceneCode(source) {
  const text = String(source || ''); if (text.length > 100000) throw new SceneCodeError('Scene code exceeds the 100 KB safety limit.');
  const tokens = tokenize(text); let index = 0;
  const current = () => tokens[index];
  const take = (type) => { const token = current(); if (token.type !== type) throw new SceneCodeError(`Expected "${type}" but found "${token.value || 'end of input'}".`, token.line, token.column); index++; return token; };
  const parseValue = (depth = 0) => {
    const token = current(); if (depth > 64) throw new SceneCodeError('Scene data is nested too deeply (maximum depth: 64).', token.line, token.column);
    if (token.type === 'string' || token.type === 'number') { index++; return token.value; }
    if (token.type === 'identifier') { index++; if (token.value === 'true') return true; if (token.value === 'false') return false; if (token.value === 'null') return null; throw new SceneCodeError(`Unsupported value "${token.value}". Use literals only.`, token.line, token.column); }
    if (token.type === '[') { take('['); const values = []; while (current().type !== ']') { values.push(parseValue(depth + 1)); if (current().type === ',') { take(','); if (current().type === ']') break; } else if (current().type !== ']') take(','); if (values.length > 5000) throw new SceneCodeError('Array is too large.', token.line, token.column); } take(']'); return values; }
    if (token.type === '{') { take('{'); const object = {}; while (current().type !== '}') { const keyToken = current(); if (keyToken.type !== 'identifier' && keyToken.type !== 'string') throw new SceneCodeError('Object keys must be plain names or strings.', keyToken.line, keyToken.column); index++; const key = String(keyToken.value); if (['__proto__', 'prototype', 'constructor'].includes(key)) throw new SceneCodeError(`Unsafe property "${key}" is not allowed.`, keyToken.line, keyToken.column); take(':'); object[key] = parseValue(depth + 1); if (current().type === ',') { take(','); if (current().type === '}') break; } else if (current().type !== '}') take(','); } take('}'); return object; }
    throw new SceneCodeError(`Expected a literal value, found "${token.value || 'end of input'}".`, token.line, token.column);
  };
  const commands = [];
  while (current().type !== 'eof') { const nameToken = take('identifier'); if (!SUPPORTED_COMMANDS.includes(nameToken.value)) throw new SceneCodeError(`Unknown command "${nameToken.value}()".`, nameToken.line, nameToken.column); take('('); const args = []; if (current().type !== ')') { args.push(parseValue()); while (current().type === ',') { take(','); if (current().type === ')') break; args.push(parseValue()); } } take(')'); if (current().type === ';') take(';'); if (args.length > 1) throw new SceneCodeError('Each command accepts one object argument.', nameToken.line, nameToken.column); commands.push({ name: nameToken.value, args, line: nameToken.line }); if (commands.length > 1000) throw new SceneCodeError('Script contains too many commands.', nameToken.line, nameToken.column); }
  return commands;
}

export function applySceneCommands(baseScene, commands) {
  const scene = cloneValue(baseScene || createScene());
  for (const command of commands) applyOneCommand(scene, command);
  if (countObjects(scene) > MAX_OBJECTS) throw new Error(`Object count limit exceeded (${MAX_OBJECTS}).`);
  return scene;
}
function applyOneCommand(scene, command) {
  const { name, args = [] } = command; const arg = args[0] && typeof args[0] === 'object' ? args[0] : {};
  if (name === 'clearScene') { scene.objects = []; scene.materials = []; return; }
  if (name === 'environment') {
    if (arg.background != null) scene.environment.background = validateColor(arg.background, 'Environment background');
    if (arg.fog != null) { const fog = arg.fog; scene.environment.fog = { color: validateColor(fog.color ?? arg.background ?? scene.environment.background, 'Fog color'), near: number(fog.near, 'Fog near', { min: 0, max: 10000, fallback: 50 }), far: number(fog.far, 'Fog far', { min: 0.1, max: 20000, fallback: 200 }) }; if (scene.environment.fog.far <= scene.environment.fog.near) throw new Error('Fog far must be greater than fog near.'); }
    if (arg.grid != null) scene.environment.grid = Boolean(arg.grid); if (arg.ground != null) scene.environment.ground = Boolean(arg.ground); if (arg.intensity != null) scene.environment.intensity = number(arg.intensity, 'Environment intensity', { min: 0, max: 4, fallback: 1 }); return;
  }
  if (name === 'camera') { scene.camera = { position: vector(arg.position, 'Camera position', scene.camera?.position || [16, 12, 19]), target: vector(arg.target, 'Camera target', scene.camera?.target || [0, 2, 0]), fov: number(arg.fov, 'Camera fov', { min: 15, max: 100, fallback: 42 }) }; return; }
  if (name === 'createMaterial') { if (!arg.name) throw new Error('createMaterial requires a name.'); const material = normalizeMaterial(arg); const i = scene.materials.findIndex((item) => item.name.toLowerCase() === String(arg.name).toLowerCase()); if (i >= 0) scene.materials[i] = material; else { if (scene.materials.length >= 100) throw new Error('Material count limit exceeded (100).'); scene.materials.push(material); } return; }
  if (name === 'createTexture') { if (!Array.isArray(scene.textures)) scene.textures = []; if (scene.textures.length >= 100) throw new Error('Texture count limit exceeded (100).'); scene.textures.push({ name: String(arg.name || `Texture ${scene.textures.length + 1}`).slice(0, 80), type: String(arg.type || 'checker'), colorA: validateColor(arg.colorA || '#ded8ca'), colorB: validateColor(arg.colorB || '#9d927b'), scale: number(arg.scale, 'Texture scale', { min: 0.1, max: 128, fallback: 8 }) }); return; }
  if (name === 'repeat' || name === 'grid' || name === 'scatter') {
    const object = arg.object; if (!object || typeof object !== 'object') throw new Error(`${name} requires an object definition.`); const specs = [];
    if (name === 'repeat') { const count = number(arg.count, 'Repeat count', { min: 1, max: MAX_REPEAT, fallback: 1 }); const step = vector(arg.step, 'Repeat step', [1, 0, 0]); const start = vector(arg.start, 'Repeat start', [0, 0, 0]); for (let i = 0; i < count; i++) specs.push({ ...object, position: [(object.position?.[0] || 0) + start[0] + step[0] * i, (object.position?.[1] || 0) + start[1] + step[1] * i, (object.position?.[2] || 0) + start[2] + step[2] * i], name: `${object.name || object.type || 'Object'} ${String(i + 1).padStart(2, '0')}` }); }
    else if (name === 'grid') { const columns = number(arg.columns, 'Grid columns', { min: 1, max: 100, fallback: 1 }); const rows = number(arg.rows, 'Grid rows', { min: 1, max: 100, fallback: 1 }); if (columns * rows > MAX_REPEAT) throw new Error(`Grid may contain at most ${MAX_REPEAT} objects.`); const spacing = Array.isArray(arg.spacing) ? arg.spacing : [2, 2]; if (spacing.length !== 2) throw new Error('Grid spacing must contain 2 numbers.'); const sx = number(spacing[0], 'Grid spacing X', { min: 0.01, max: 10000, fallback: 2 }); const sz = number(spacing[1], 'Grid spacing Z', { min: 0.01, max: 10000, fallback: 2 }); const center = vector(arg.center, 'Grid center', [0, 0, 0]); for (let z = 0; z < rows; z++) for (let x = 0; x < columns; x++) specs.push({ ...object, position: [center[0] + (x - (columns - 1) / 2) * sx, center[1] + (object.position?.[1] || 0), center[2] + (z - (rows - 1) / 2) * sz], name: `${object.name || object.type || 'Object'} ${String(z * columns + x + 1).padStart(2, '0')}` }); }
    else { const count = number(arg.count, 'Scatter count', { min: 1, max: MAX_REPEAT, fallback: 1 }); const area = Array.isArray(arg.area) ? arg.area : [10, 10]; if (area.length !== 2) throw new Error('Scatter area must contain 2 numbers.'); const width = number(area[0], 'Scatter area width', { min: 0.1, max: 10000, fallback: 10 }); const depth = number(area[1], 'Scatter area depth', { min: 0.1, max: 10000, fallback: 10 }); const center = vector(arg.center, 'Scatter center', [0, 0, 0]); let seed = (Number(arg.seed) || 12345) >>> 0; const random = () => { seed = (seed + 0x6D2B79F5) >>> 0; let t = seed; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; for (let i = 0; i < count; i++) specs.push({ ...object, position: [center[0] + (random() - 0.5) * width, center[1] + (object.position?.[1] || 0), center[2] + (random() - 0.5) * depth], rotation: [0, random() * Math.PI * 2, 0], scale: object.scale || [1, 1, 1], name: `${object.name || object.type || 'Object'} ${String(i + 1).padStart(2, '0')}` }); }
    for (const spec of specs) addNode(scene, createNode(spec.type || 'box', spec), arg.parent || null); return;
  }
  if (['setPosition', 'setRotation', 'setScale', 'setMaterial'].includes(name)) { const target = arg.objectId || arg.name || arg.object; if (!target) throw new Error(`${name} needs an objectId or name.`); const patch = name === 'setPosition' ? { position: arg.position } : name === 'setRotation' ? { rotation: arg.rotation } : name === 'setScale' ? { scale: arg.scale } : { material: arg.material }; updateNode(scene, target, patch); return; }
  if (name === 'deleteObject') { const target = arg.objectId || arg.name || arg.object; if (!removeNode(scene, target)) throw new Error(`Object "${target}" was not found.`); return; }
  if (name === 'duplicate' || name === 'clone') { const target = arg.objectId || arg.name || arg.object; const copy = duplicateNode(scene, target); if (arg.offset) copy.position = vector(arg.offset, 'Duplicate offset', [1.25, 0, 0]); return; }
  const type = COMMAND_TO_TYPE[name]; if (!type) throw new Error(`Unknown command "${name}()."`); addNode(scene, createNode(type, arg), arg.parent || null);
}

export function normalizeSceneData(input) {
  if (!input || typeof input !== 'object' || input.version !== 1 || !Array.isArray(input.objects)) throw new Error('Invalid Scene JSON.');
  if (input.objects.length > MAX_OBJECTS) throw new Error(`Object count limit exceeded (${MAX_OBJECTS}).`);
  const scene = createScene(input.scene?.name || 'Untitled Scene');
  scene.materials = Array.isArray(input.materials) ? input.materials.slice(0, 100).map((material) => normalizeMaterial(material)) : [];
  scene.objects = input.objects.map((node) => createNode(node.type, node, 0));
  if (countObjects(scene) > MAX_OBJECTS) throw new Error(`Object count limit exceeded (${MAX_OBJECTS}).`);
  const ids = new Set(); walkNodes(scene.objects, (node) => { if (ids.has(node.id)) throw new Error(`Duplicate object ID "${node.id}".`); ids.add(node.id); });
  scene.environment = cloneValue(createScene().environment);
  const envScene = applySceneCommands(scene, [{ name: 'environment', args: [input.environment || {}] }]);
  scene.environment = envScene.environment;
  if (input.camera && typeof input.camera === 'object') scene.camera = { position: vector(input.camera.position, 'Camera position', [16, 12, 19]), target: vector(input.camera.target, 'Camera target', [0, 2, 0]), fov: number(input.camera.fov, 'Camera fov', { min: 15, max: 100, fallback: 42 }) };
  if (Array.isArray(input.textures)) scene.textures = input.textures.slice(0, 100).map((texture) => ({ name: String(texture.name || 'Texture').slice(0, 80), type: String(texture.type || 'checker'), colorA: validateColor(texture.colorA || '#ded8ca'), colorB: validateColor(texture.colorB || '#9d927b'), scale: number(texture.scale, 'Texture scale', { min: .1, max: 128, fallback: 8 }) }));
  return scene;
}

function cleanNodeForCode(node) { const out = { ...node }; delete out.id; if (node.children?.length) out.children = node.children.map((child) => ({ type: child.type, ...cleanNodeForCode(child) })); else delete out.children; return out; }
export function sceneToCode(scene) {
  const lines = []; if (scene.environment) lines.push(`environment(${JSON.stringify(scene.environment, null, 2)});`);
  for (const material of scene.materials || []) lines.push(`createMaterial(${JSON.stringify(material, null, 2)});`);
  if (scene.camera) lines.push(`camera(${JSON.stringify(scene.camera, null, 2)});`);
  const commandFor = (node) => { const functionName = node.type === 'group' ? 'group' : LIGHT_TYPES.includes(node.type) ? node.type : `create${node.type[0].toUpperCase()}${node.type.slice(1)}`; return `${functionName}(${JSON.stringify(cleanNodeForCode(node), null, 2)});`; };
  for (const node of scene.objects || []) lines.push(commandFor(node)); return lines.join('\n\n');
}
export function formatSceneCode(source) { return parseSceneCode(source).map(({ name, args }) => `${name}(${args.length ? JSON.stringify(args[0], null, 2) : ''});`).join('\n\n'); }
export function flattenObjects(scene) { const objects = []; walkNodes(scene?.objects, (node, parent) => objects.push({ id: node.id, name: node.name, type: node.type, parentId: parent?.id || null, position: node.position, visible: node.visible })); return objects; }
